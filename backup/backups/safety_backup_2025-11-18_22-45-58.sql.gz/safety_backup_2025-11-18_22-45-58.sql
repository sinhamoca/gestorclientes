--
-- PostgreSQL database dump
--

\restrict WUYxPsVeCtZDao8NMiWvOxM4oXqkaqXdbCt0eEIpGQNB8gMOe1MdtmKMxMifdQX

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: audit_trigger_func(); Type: FUNCTION; Schema: public; Owner: gestao_user
--

CREATE FUNCTION public.audit_trigger_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    audit_row audit_log;
    record_id_value TEXT;
BEGIN
    -- Determinar o ID do registro
    IF TG_OP = 'DELETE' THEN
        record_id_value := OLD.id::TEXT;
    ELSE
        record_id_value := NEW.id::TEXT;
    END IF;

    -- Inserir log de auditoria
    IF TG_OP = 'INSERT' THEN
        INSERT INTO audit_log (
            table_name,
            operation,
            record_id,
            new_data,
            changed_by
        ) VALUES (
            TG_TABLE_NAME,
            'INSERT',
            record_id_value,
            row_to_json(NEW)::JSONB,
            current_user
        );
    ELSIF TG_OP = 'UPDATE' THEN
        INSERT INTO audit_log (
            table_name,
            operation,
            record_id,
            old_data,
            new_data,
            changed_by
        ) VALUES (
            TG_TABLE_NAME,
            'UPDATE',
            record_id_value,
            row_to_json(OLD)::JSONB,
            row_to_json(NEW)::JSONB,
            current_user
        );
    ELSIF TG_OP = 'DELETE' THEN
        INSERT INTO audit_log (
            table_name,
            operation,
            record_id,
            old_data,
            changed_by
        ) VALUES (
            TG_TABLE_NAME,
            'DELETE',
            record_id_value,
            row_to_json(OLD)::JSONB,
            current_user
        );
    END IF;

    IF TG_OP = 'DELETE' THEN
        RETURN OLD;
    ELSE
        RETURN NEW;
    END IF;
END;
$$;


ALTER FUNCTION public.audit_trigger_func() OWNER TO gestao_user;

--
-- Name: cleanup_old_audit_logs(); Type: FUNCTION; Schema: public; Owner: gestao_user
--

CREATE FUNCTION public.cleanup_old_audit_logs() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM audit_log
    WHERE changed_at < NOW() - INTERVAL '90 days';
END;
$$;


ALTER FUNCTION public.cleanup_old_audit_logs() OWNER TO gestao_user;

--
-- Name: generate_payment_token(); Type: FUNCTION; Schema: public; Owner: gestao_user
--

CREATE FUNCTION public.generate_payment_token() RETURNS character varying
    LANGUAGE plpgsql
    AS $$
      DECLARE
        new_token VARCHAR(100);
        token_exists BOOLEAN;
      BEGIN
        LOOP
          new_token := md5(random()::text || clock_timestamp()::text);
          SELECT EXISTS(SELECT 1 FROM clients WHERE payment_token = new_token) INTO token_exists;
          IF NOT token_exists THEN
            RETURN new_token;
          END IF;
        END LOOP;
      END;
      $$;


ALTER FUNCTION public.generate_payment_token() OWNER TO gestao_user;

--
-- Name: set_payment_token(); Type: FUNCTION; Schema: public; Owner: gestao_user
--

CREATE FUNCTION public.set_payment_token() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
      BEGIN
        IF NEW.payment_token IS NULL THEN
          NEW.payment_token := generate_payment_token();
        END IF;
        RETURN NEW;
      END;
      $$;


ALTER FUNCTION public.set_payment_token() OWNER TO gestao_user;

--
-- Name: update_unitv_codes_updated_at(); Type: FUNCTION; Schema: public; Owner: gestao_user
--

CREATE FUNCTION public.update_unitv_codes_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
      BEGIN
        NEW.updated_at = NOW();
        RETURN NEW;
      END;
      $$;


ALTER FUNCTION public.update_unitv_codes_updated_at() OWNER TO gestao_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: gestao_user
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    table_name character varying(255) NOT NULL,
    operation character varying(10) NOT NULL,
    record_id character varying(255),
    old_data jsonb,
    new_data jsonb,
    changed_by character varying(255),
    changed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    ip_address character varying(45),
    user_agent text,
    session_id character varying(255)
);


ALTER TABLE public.audit_log OWNER TO gestao_user;

--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: gestao_user
--

CREATE SEQUENCE public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audit_log_id_seq OWNER TO gestao_user;

--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gestao_user
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: clients; Type: TABLE; Schema: public; Owner: gestao_user
--

CREATE TABLE public.clients (
    id integer NOT NULL,
    user_id integer,
    name character varying(100) NOT NULL,
    whatsapp_number character varying(20) NOT NULL,
    plan_id integer,
    server_id integer,
    price_value numeric(10,2) NOT NULL,
    due_date date NOT NULL,
    username character varying(100),
    password character varying(100),
    mac_address character varying(50),
    device_key character varying(100),
    notes text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    payment_token character varying(100)
);


ALTER TABLE public.clients OWNER TO gestao_user;

--
-- Name: clients_id_seq; Type: SEQUENCE; Schema: public; Owner: gestao_user
--

CREATE SEQUENCE public.clients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.clients_id_seq OWNER TO gestao_user;

--
-- Name: clients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gestao_user
--

ALTER SEQUENCE public.clients_id_seq OWNED BY public.clients.id;


--
-- Name: financial_transactions; Type: TABLE; Schema: public; Owner: gestao_user
--

CREATE TABLE public.financial_transactions (
    id integer NOT NULL,
    user_id integer,
    client_id integer,
    type character varying(20) NOT NULL,
    amount_received numeric(10,2) NOT NULL,
    server_cost numeric(10,2) NOT NULL,
    net_profit numeric(10,2) NOT NULL,
    due_date date NOT NULL,
    paid_date timestamp without time zone,
    status character varying(20) DEFAULT 'pending'::character varying,
    payment_method character varying(50),
    notes text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    payment_gateway character varying(50),
    gateway_payment_id character varying(255),
    payment_session_id integer,
    unitv_code_id integer
);


ALTER TABLE public.financial_transactions OWNER TO gestao_user;

--
-- Name: financial_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: gestao_user
--

CREATE SEQUENCE public.financial_transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.financial_transactions_id_seq OWNER TO gestao_user;

--
-- Name: financial_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gestao_user
--

ALTER SEQUENCE public.financial_transactions_id_seq OWNED BY public.financial_transactions.id;


--
-- Name: message_logs; Type: TABLE; Schema: public; Owner: gestao_user
--

CREATE TABLE public.message_logs (
    id integer NOT NULL,
    user_id integer,
    client_id integer,
    reminder_id integer,
    template_id integer,
    message_sent text NOT NULL,
    whatsapp_number character varying(20) NOT NULL,
    sent_at timestamp without time zone DEFAULT now(),
    status character varying(20) DEFAULT 'pending'::character varying,
    error_message text
);


ALTER TABLE public.message_logs OWNER TO gestao_user;

--
-- Name: message_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: gestao_user
--

CREATE SEQUENCE public.message_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.message_logs_id_seq OWNER TO gestao_user;

--
-- Name: message_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gestao_user
--

ALTER SEQUENCE public.message_logs_id_seq OWNED BY public.message_logs.id;


--
-- Name: message_queue; Type: TABLE; Schema: public; Owner: gestao_user
--

CREATE TABLE public.message_queue (
    id integer NOT NULL,
    user_id integer,
    instance_name character varying(100) NOT NULL,
    client_id integer,
    reminder_id integer,
    template_id integer,
    whatsapp_number character varying(20) NOT NULL,
    message text NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying,
    priority integer DEFAULT 0,
    scheduled_for timestamp without time zone NOT NULL,
    attempts integer DEFAULT 0,
    last_attempt timestamp without time zone,
    error_message text,
    created_at timestamp without time zone DEFAULT now(),
    sent_at timestamp without time zone,
    send_once boolean DEFAULT false
);


ALTER TABLE public.message_queue OWNER TO gestao_user;

--
-- Name: message_queue_id_seq; Type: SEQUENCE; Schema: public; Owner: gestao_user
--

CREATE SEQUENCE public.message_queue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.message_queue_id_seq OWNER TO gestao_user;

--
-- Name: message_queue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gestao_user
--

ALTER SEQUENCE public.message_queue_id_seq OWNED BY public.message_queue.id;


--
-- Name: message_templates; Type: TABLE; Schema: public; Owner: gestao_user
--

CREATE TABLE public.message_templates (
    id integer NOT NULL,
    user_id integer,
    name character varying(100) NOT NULL,
    type character varying(50) NOT NULL,
    message text NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.message_templates OWNER TO gestao_user;

--
-- Name: message_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: gestao_user
--

CREATE SEQUENCE public.message_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.message_templates_id_seq OWNER TO gestao_user;

--
-- Name: message_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gestao_user
--

ALTER SEQUENCE public.message_templates_id_seq OWNED BY public.message_templates.id;


--
-- Name: payment_sessions; Type: TABLE; Schema: public; Owner: gestao_user
--

CREATE TABLE public.payment_sessions (
    id integer NOT NULL,
    client_id integer,
    user_id integer,
    payment_token character varying(100) NOT NULL,
    session_token character varying(100) NOT NULL,
    mercadopago_preference_id character varying(255),
    mercadopago_payment_id character varying(255),
    mercadopago_init_point text,
    amount numeric(10,2) NOT NULL,
    currency character varying(3) DEFAULT 'BRL'::character varying,
    status character varying(20) DEFAULT 'pending'::character varying,
    payment_method character varying(50),
    created_at timestamp without time zone DEFAULT now(),
    expires_at timestamp without time zone,
    paid_at timestamp without time zone,
    metadata jsonb
);


ALTER TABLE public.payment_sessions OWNER TO gestao_user;

--
-- Name: payment_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: gestao_user
--

CREATE SEQUENCE public.payment_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payment_sessions_id_seq OWNER TO gestao_user;

--
-- Name: payment_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gestao_user
--

ALTER SEQUENCE public.payment_sessions_id_seq OWNED BY public.payment_sessions.id;


--
-- Name: payment_settings; Type: TABLE; Schema: public; Owner: gestao_user
--

CREATE TABLE public.payment_settings (
    id integer NOT NULL,
    user_id integer,
    mercadopago_enabled boolean DEFAULT false,
    mercadopago_access_token text,
    mercadopago_public_key text,
    payment_domain character varying(255),
    session_expiration_hours integer DEFAULT 24,
    send_confirmation_whatsapp boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.payment_settings OWNER TO gestao_user;

--
-- Name: payment_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: gestao_user
--

CREATE SEQUENCE public.payment_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payment_settings_id_seq OWNER TO gestao_user;

--
-- Name: payment_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gestao_user
--

ALTER SEQUENCE public.payment_settings_id_seq OWNED BY public.payment_settings.id;


--
-- Name: plans; Type: TABLE; Schema: public; Owner: gestao_user
--

CREATE TABLE public.plans (
    id integer NOT NULL,
    user_id integer,
    name character varying(100) NOT NULL,
    duration_months integer NOT NULL,
    num_screens integer DEFAULT 1,
    created_at timestamp without time zone DEFAULT now(),
    is_sigma_plan boolean DEFAULT false,
    sigma_plan_code character varying(100),
    sigma_domain character varying(255),
    is_live21_plan boolean DEFAULT false,
    is_koffice_plan boolean DEFAULT false,
    koffice_domain character varying(255),
    is_uniplay_plan boolean DEFAULT false,
    is_unitv_plan boolean DEFAULT false
);


ALTER TABLE public.plans OWNER TO gestao_user;

--
-- Name: plans_id_seq; Type: SEQUENCE; Schema: public; Owner: gestao_user
--

CREATE SEQUENCE public.plans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.plans_id_seq OWNER TO gestao_user;

--
-- Name: plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gestao_user
--

ALTER SEQUENCE public.plans_id_seq OWNED BY public.plans.id;


--
-- Name: reminder_sent_log; Type: TABLE; Schema: public; Owner: gestao_user
--

CREATE TABLE public.reminder_sent_log (
    id integer NOT NULL,
    reminder_id integer,
    client_id integer,
    sent_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.reminder_sent_log OWNER TO gestao_user;

--
-- Name: reminder_sent_log_id_seq; Type: SEQUENCE; Schema: public; Owner: gestao_user
--

CREATE SEQUENCE public.reminder_sent_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reminder_sent_log_id_seq OWNER TO gestao_user;

--
-- Name: reminder_sent_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gestao_user
--

ALTER SEQUENCE public.reminder_sent_log_id_seq OWNED BY public.reminder_sent_log.id;


--
-- Name: reminders; Type: TABLE; Schema: public; Owner: gestao_user
--

CREATE TABLE public.reminders (
    id integer NOT NULL,
    user_id integer,
    name character varying(100) NOT NULL,
    template_id integer,
    days_offset integer NOT NULL,
    send_time time without time zone DEFAULT '09:00:00'::time without time zone,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    send_once boolean DEFAULT false
);


ALTER TABLE public.reminders OWNER TO gestao_user;

--
-- Name: reminders_id_seq; Type: SEQUENCE; Schema: public; Owner: gestao_user
--

CREATE SEQUENCE public.reminders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reminders_id_seq OWNER TO gestao_user;

--
-- Name: reminders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gestao_user
--

ALTER SEQUENCE public.reminders_id_seq OWNED BY public.reminders.id;


--
-- Name: securevault_users; Type: TABLE; Schema: public; Owner: gestao_user
--

CREATE TABLE public.securevault_users (
    id integer NOT NULL,
    username character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    totp_secret character varying(100),
    totp_enabled boolean DEFAULT false,
    is_admin boolean DEFAULT true,
    last_login timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.securevault_users OWNER TO gestao_user;

--
-- Name: securevault_users_id_seq; Type: SEQUENCE; Schema: public; Owner: gestao_user
--

CREATE SEQUENCE public.securevault_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.securevault_users_id_seq OWNER TO gestao_user;

--
-- Name: securevault_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gestao_user
--

ALTER SEQUENCE public.securevault_users_id_seq OWNED BY public.securevault_users.id;


--
-- Name: servers; Type: TABLE; Schema: public; Owner: gestao_user
--

CREATE TABLE public.servers (
    id integer NOT NULL,
    user_id integer,
    name character varying(100) NOT NULL,
    cost_per_screen numeric(10,2) NOT NULL,
    multiply_by_screens boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.servers OWNER TO gestao_user;

--
-- Name: servers_id_seq; Type: SEQUENCE; Schema: public; Owner: gestao_user
--

CREATE SEQUENCE public.servers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.servers_id_seq OWNER TO gestao_user;

--
-- Name: servers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gestao_user
--

ALTER SEQUENCE public.servers_id_seq OWNED BY public.servers.id;


--
-- Name: transaction_unitv_codes; Type: TABLE; Schema: public; Owner: gestao_user
--

CREATE TABLE public.transaction_unitv_codes (
    id integer NOT NULL,
    transaction_id integer NOT NULL,
    unitv_code_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.transaction_unitv_codes OWNER TO gestao_user;

--
-- Name: transaction_unitv_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: gestao_user
--

CREATE SEQUENCE public.transaction_unitv_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.transaction_unitv_codes_id_seq OWNER TO gestao_user;

--
-- Name: transaction_unitv_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gestao_user
--

ALTER SEQUENCE public.transaction_unitv_codes_id_seq OWNED BY public.transaction_unitv_codes.id;


--
-- Name: unitv_codes; Type: TABLE; Schema: public; Owner: gestao_user
--

CREATE TABLE public.unitv_codes (
    id integer NOT NULL,
    user_id integer NOT NULL,
    code character varying(16) NOT NULL,
    status character varying(20) DEFAULT 'available'::character varying,
    delivered_to_client_id integer,
    delivered_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    CONSTRAINT unitv_codes_status_check CHECK (((status)::text = ANY (ARRAY[('available'::character varying)::text, ('delivered'::character varying)::text]))),
    CONSTRAINT valid_code_format CHECK (((code)::text ~ '^[0-9]{16}$'::text))
);


ALTER TABLE public.unitv_codes OWNER TO gestao_user;

--
-- Name: unitv_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: gestao_user
--

CREATE SEQUENCE public.unitv_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.unitv_codes_id_seq OWNER TO gestao_user;

--
-- Name: unitv_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gestao_user
--

ALTER SEQUENCE public.unitv_codes_id_seq OWNED BY public.unitv_codes.id;


--
-- Name: user_subscription_payments; Type: TABLE; Schema: public; Owner: gestao_user
--

CREATE TABLE public.user_subscription_payments (
    id integer NOT NULL,
    user_id integer,
    mercadopago_payment_id character varying(255),
    amount numeric(10,2) NOT NULL,
    days_added integer DEFAULT 30 NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying,
    payment_method character varying(50) DEFAULT 'pix'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    paid_at timestamp without time zone,
    previous_subscription_end date,
    new_subscription_end date,
    metadata jsonb
);


ALTER TABLE public.user_subscription_payments OWNER TO gestao_user;

--
-- Name: user_subscription_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: gestao_user
--

CREATE SEQUENCE public.user_subscription_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_subscription_payments_id_seq OWNER TO gestao_user;

--
-- Name: user_subscription_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gestao_user
--

ALTER SEQUENCE public.user_subscription_payments_id_seq OWNED BY public.user_subscription_payments.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: gestao_user
--

CREATE TABLE public.users (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    email character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    phone character varying(20),
    role character varying(20) DEFAULT 'user'::character varying,
    subscription_start date,
    subscription_end date,
    is_active boolean DEFAULT true,
    max_clients integer DEFAULT 100,
    max_instances integer DEFAULT 1,
    messages_per_minute integer DEFAULT 5,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.users OWNER TO gestao_user;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: gestao_user
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO gestao_user;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gestao_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: whatsapp_instances; Type: TABLE; Schema: public; Owner: gestao_user
--

CREATE TABLE public.whatsapp_instances (
    id integer NOT NULL,
    user_id integer,
    instance_name character varying(100) NOT NULL,
    instance_id character varying(100),
    phone_number character varying(20),
    status character varying(20) DEFAULT 'disconnected'::character varying,
    qr_code text,
    qr_code_updated_at timestamp without time zone,
    connected_at timestamp without time zone,
    last_ping timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    provider character varying(50) DEFAULT 'wppconnect'::character varying
);


ALTER TABLE public.whatsapp_instances OWNER TO gestao_user;

--
-- Name: whatsapp_instances_id_seq; Type: SEQUENCE; Schema: public; Owner: gestao_user
--

CREATE SEQUENCE public.whatsapp_instances_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.whatsapp_instances_id_seq OWNER TO gestao_user;

--
-- Name: whatsapp_instances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gestao_user
--

ALTER SEQUENCE public.whatsapp_instances_id_seq OWNED BY public.whatsapp_instances.id;


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: clients id; Type: DEFAULT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.clients ALTER COLUMN id SET DEFAULT nextval('public.clients_id_seq'::regclass);


--
-- Name: financial_transactions id; Type: DEFAULT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.financial_transactions ALTER COLUMN id SET DEFAULT nextval('public.financial_transactions_id_seq'::regclass);


--
-- Name: message_logs id; Type: DEFAULT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.message_logs ALTER COLUMN id SET DEFAULT nextval('public.message_logs_id_seq'::regclass);


--
-- Name: message_queue id; Type: DEFAULT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.message_queue ALTER COLUMN id SET DEFAULT nextval('public.message_queue_id_seq'::regclass);


--
-- Name: message_templates id; Type: DEFAULT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.message_templates ALTER COLUMN id SET DEFAULT nextval('public.message_templates_id_seq'::regclass);


--
-- Name: payment_sessions id; Type: DEFAULT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.payment_sessions ALTER COLUMN id SET DEFAULT nextval('public.payment_sessions_id_seq'::regclass);


--
-- Name: payment_settings id; Type: DEFAULT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.payment_settings ALTER COLUMN id SET DEFAULT nextval('public.payment_settings_id_seq'::regclass);


--
-- Name: plans id; Type: DEFAULT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.plans ALTER COLUMN id SET DEFAULT nextval('public.plans_id_seq'::regclass);


--
-- Name: reminder_sent_log id; Type: DEFAULT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.reminder_sent_log ALTER COLUMN id SET DEFAULT nextval('public.reminder_sent_log_id_seq'::regclass);


--
-- Name: reminders id; Type: DEFAULT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.reminders ALTER COLUMN id SET DEFAULT nextval('public.reminders_id_seq'::regclass);


--
-- Name: securevault_users id; Type: DEFAULT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.securevault_users ALTER COLUMN id SET DEFAULT nextval('public.securevault_users_id_seq'::regclass);


--
-- Name: servers id; Type: DEFAULT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.servers ALTER COLUMN id SET DEFAULT nextval('public.servers_id_seq'::regclass);


--
-- Name: transaction_unitv_codes id; Type: DEFAULT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.transaction_unitv_codes ALTER COLUMN id SET DEFAULT nextval('public.transaction_unitv_codes_id_seq'::regclass);


--
-- Name: unitv_codes id; Type: DEFAULT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.unitv_codes ALTER COLUMN id SET DEFAULT nextval('public.unitv_codes_id_seq'::regclass);


--
-- Name: user_subscription_payments id; Type: DEFAULT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.user_subscription_payments ALTER COLUMN id SET DEFAULT nextval('public.user_subscription_payments_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: whatsapp_instances id; Type: DEFAULT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.whatsapp_instances ALTER COLUMN id SET DEFAULT nextval('public.whatsapp_instances_id_seq'::regclass);


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: gestao_user
--

COPY public.audit_log (id, table_name, operation, record_id, old_data, new_data, changed_by, changed_at, ip_address, user_agent, session_id) FROM stdin;
1	clients	DELETE	4	{"id": 4, "name": "Milena ribeiro ", "notes": "", "plan_id": 14, "user_id": 2, "due_date": "2026-02-08", "password": "", "username": " ", "is_active": true, "server_id": 1, "created_at": "2025-11-08T10:40:06.606119", "device_key": "", "updated_at": "2025-11-17T23:36:08.088111", "mac_address": "", "price_value": 40.00, "payment_token": "92bc7106be61a819ab387c2750eed9db", "whatsapp_number": "558594021963"}	\N	gestao_user	2025-11-18 23:35:01.521253	\N	\N	\N
2	financial_transactions	DELETE	36	{"id": 36, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2025-12-08", "client_id": 4, "paid_date": "2025-11-08T12:00:00", "created_at": "2025-11-08T10:40:13.291449", "net_profit": 38.00, "updated_at": "2025-11-08T10:40:13.291449", "server_cost": 2.00, "unitv_code_id": null, "payment_method": "pix", "amount_received": 40.00, "payment_gateway": null, "gateway_payment_id": null, "payment_session_id": null}	\N	gestao_user	2025-11-18 23:35:01.521253	\N	\N	\N
3	financial_transactions	DELETE	91	{"id": 91, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2026-01-08", "client_id": 4, "paid_date": "2025-11-17T23:35:53.963", "created_at": "2025-11-17T23:35:53.964484", "net_profit": 38.00, "updated_at": "2025-11-17T23:35:53.964484", "server_cost": 2.00, "unitv_code_id": null, "payment_method": "pix", "amount_received": 40.00, "payment_gateway": null, "gateway_payment_id": null, "payment_session_id": null}	\N	gestao_user	2025-11-18 23:35:01.521253	\N	\N	\N
4	financial_transactions	DELETE	92	{"id": 92, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2026-02-08", "client_id": 4, "paid_date": "2025-11-17T23:36:08.092", "created_at": "2025-11-17T23:36:08.092979", "net_profit": 38.00, "updated_at": "2025-11-17T23:36:08.092979", "server_cost": 2.00, "unitv_code_id": null, "payment_method": "pix", "amount_received": 40.00, "payment_gateway": null, "gateway_payment_id": null, "payment_session_id": null}	\N	gestao_user	2025-11-18 23:35:01.521253	\N	\N	\N
5	payment_sessions	DELETE	87	{"id": 87, "amount": 40.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 40, "card_amount": 44, "client_name": "Letícia Perdigão"}, "client_id": 4, "created_at": "2025-11-17T18:45:51.601645", "expires_at": "2025-11-18T18:45:51.6", "payment_token": "92bc7106be61a819ab387c2750eed9db", "session_token": "e9a084798b2b7ddf9c8f6d70cc86970cb8a19c92ff299f606f0071391fdea279", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": "133631504131", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:01.521253	\N	\N	\N
6	clients	DELETE	6	{"id": 6, "name": "teste da unitv", "notes": "", "plan_id": 21, "user_id": 2, "due_date": "2026-12-17", "password": "", "username": "1", "is_active": true, "server_id": 2, "created_at": "2025-11-17T20:58:29.876225", "device_key": "", "updated_at": "2025-11-17T23:20:52.171744", "mac_address": "", "price_value": 1.00, "payment_token": "0db2ad7fece3055632b1d18c033a9b75", "whatsapp_number": "558594021963"}	\N	gestao_user	2025-11-18 23:35:07.193825	\N	\N	\N
7	financial_transactions	DELETE	82	{"id": 82, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2025-11-17", "client_id": 6, "paid_date": "2025-11-17T20:59:10.626502", "created_at": "2025-11-17T20:59:10.626502", "net_profit": -2.00, "updated_at": "2025-11-17T20:59:10.626502", "server_cost": 3.00, "unitv_code_id": null, "payment_method": "bank_transfer", "amount_received": 1.00, "payment_gateway": "mercadopago", "gateway_payment_id": "134256587372", "payment_session_id": 121}	\N	gestao_user	2025-11-18 23:35:07.193825	\N	\N	\N
8	financial_transactions	DELETE	83	{"id": 83, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2025-12-17", "client_id": 6, "paid_date": "2025-11-17T21:12:43.021504", "created_at": "2025-11-17T21:12:43.021504", "net_profit": -2.00, "updated_at": "2025-11-17T21:12:43.021504", "server_cost": 3.00, "unitv_code_id": null, "payment_method": "bank_transfer", "amount_received": 1.00, "payment_gateway": "mercadopago", "gateway_payment_id": "134258243322", "payment_session_id": 125}	\N	gestao_user	2025-11-18 23:35:07.193825	\N	\N	\N
9	financial_transactions	DELETE	84	{"id": 84, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2026-01-17", "client_id": 6, "paid_date": "2025-11-17T21:13:53.905414", "created_at": "2025-11-17T21:13:53.905414", "net_profit": -2.00, "updated_at": "2025-11-17T21:13:53.905414", "server_cost": 3.00, "unitv_code_id": null, "payment_method": "bank_transfer", "amount_received": 1.00, "payment_gateway": "mercadopago", "gateway_payment_id": "133648495833", "payment_session_id": 128}	\N	gestao_user	2025-11-18 23:35:07.193825	\N	\N	\N
10	financial_transactions	DELETE	85	{"id": 85, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2026-05-17", "client_id": 6, "paid_date": "2025-11-17T23:07:44.75", "created_at": "2025-11-17T23:07:44.750932", "net_profit": -2.00, "updated_at": "2025-11-17T23:07:44.750932", "server_cost": 3.00, "unitv_code_id": null, "payment_method": "pix", "amount_received": 1.00, "payment_gateway": null, "gateway_payment_id": null, "payment_session_id": null}	\N	gestao_user	2025-11-18 23:35:07.193825	\N	\N	\N
11	financial_transactions	DELETE	86	{"id": 86, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2026-06-17", "client_id": 6, "paid_date": "2025-11-17T23:08:04.401", "created_at": "2025-11-17T23:08:04.403358", "net_profit": -2.00, "updated_at": "2025-11-17T23:08:04.403358", "server_cost": 3.00, "unitv_code_id": null, "payment_method": "pix", "amount_received": 1.00, "payment_gateway": null, "gateway_payment_id": null, "payment_session_id": null}	\N	gestao_user	2025-11-18 23:35:07.193825	\N	\N	\N
12	financial_transactions	DELETE	87	{"id": 87, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2026-07-17", "client_id": 6, "paid_date": "2025-11-17T23:13:09.872", "created_at": "2025-11-17T23:13:09.872926", "net_profit": -2.00, "updated_at": "2025-11-17T23:13:09.872926", "server_cost": 3.00, "unitv_code_id": null, "payment_method": "pix", "amount_received": 1.00, "payment_gateway": null, "gateway_payment_id": null, "payment_session_id": null}	\N	gestao_user	2025-11-18 23:35:07.193825	\N	\N	\N
13	financial_transactions	DELETE	88	{"id": 88, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2026-08-17", "client_id": 6, "paid_date": "2025-11-17T23:13:46.458", "created_at": "2025-11-17T23:13:46.458555", "net_profit": -2.00, "updated_at": "2025-11-17T23:13:46.458555", "server_cost": 3.00, "unitv_code_id": null, "payment_method": "pix", "amount_received": 1.00, "payment_gateway": null, "gateway_payment_id": null, "payment_session_id": null}	\N	gestao_user	2025-11-18 23:35:07.193825	\N	\N	\N
14	financial_transactions	DELETE	89	{"id": 89, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2026-09-17", "client_id": 6, "paid_date": "2025-11-17T23:20:02.041", "created_at": "2025-11-17T23:20:02.041976", "net_profit": -2.00, "updated_at": "2025-11-17T23:20:02.041976", "server_cost": 3.00, "unitv_code_id": null, "payment_method": "pix", "amount_received": 1.00, "payment_gateway": null, "gateway_payment_id": null, "payment_session_id": null}	\N	gestao_user	2025-11-18 23:35:07.193825	\N	\N	\N
15	financial_transactions	DELETE	90	{"id": 90, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2026-12-17", "client_id": 6, "paid_date": "2025-11-17T23:20:52.175", "created_at": "2025-11-17T23:20:52.176065", "net_profit": -2.00, "updated_at": "2025-11-17T23:20:52.176065", "server_cost": 3.00, "unitv_code_id": null, "payment_method": "pix", "amount_received": 1.00, "payment_gateway": null, "gateway_payment_id": null, "payment_session_id": null}	\N	gestao_user	2025-11-18 23:35:07.193825	\N	\N	\N
16	payment_sessions	DELETE	121	{"id": 121, "amount": 1.00, "status": "paid", "paid_at": "2025-11-17T20:59:10.60634", "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "teste da unitv"}, "client_id": 6, "created_at": "2025-11-17T20:58:36.815283", "expires_at": "2025-11-18T20:58:36.814", "payment_token": "0db2ad7fece3055632b1d18c033a9b75", "session_token": "8169a259ef99068b01d0a25ac8c865a6756aed6eaba95c7aaa194a4b36fb7aca", "payment_method": "bank_transfer", "mercadopago_init_point": null, "mercadopago_payment_id": "134256587372", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:07.193825	\N	\N	\N
17	payment_sessions	DELETE	122	{"id": 122, "amount": 1.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "teste da unitv"}, "client_id": 6, "created_at": "2025-11-17T20:59:18.964399", "expires_at": "2025-11-18T20:59:18.963", "payment_token": "0db2ad7fece3055632b1d18c033a9b75", "session_token": "3d60a8b8c9e1975271bd718afd113b482f76054621856761bdb51cb5ad2aab9c", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:07.193825	\N	\N	\N
18	payment_sessions	DELETE	123	{"id": 123, "amount": 1.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "teste da unitv"}, "client_id": 6, "created_at": "2025-11-17T20:59:49.145987", "expires_at": "2025-11-18T20:59:49.145", "payment_token": "0db2ad7fece3055632b1d18c033a9b75", "session_token": "10fbdec38d70ebca2c84753503595e3b57115ff38abdf9b47a953c209362c9e1", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:07.193825	\N	\N	\N
19	payment_sessions	DELETE	124	{"id": 124, "amount": 1.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "teste da unitv"}, "client_id": 6, "created_at": "2025-11-17T21:08:38.375627", "expires_at": "2025-11-18T21:08:38.374", "payment_token": "0db2ad7fece3055632b1d18c033a9b75", "session_token": "62699602049c39458266a104b4edb2c61ffc534951e1ec7f7848378a108d33ed", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:07.193825	\N	\N	\N
20	payment_sessions	DELETE	125	{"id": 125, "amount": 1.00, "status": "paid", "paid_at": "2025-11-17T21:12:43.006558", "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "teste da unitv"}, "client_id": 6, "created_at": "2025-11-17T21:12:12.276872", "expires_at": "2025-11-18T21:12:12.275", "payment_token": "0db2ad7fece3055632b1d18c033a9b75", "session_token": "aee4f68cb4cd353f3ddb82e07e49a81aada4c0ece37ee468e248213d8cd1c0b7", "payment_method": "bank_transfer", "mercadopago_init_point": null, "mercadopago_payment_id": "134258243322", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:07.193825	\N	\N	\N
21	payment_sessions	DELETE	126	{"id": 126, "amount": 1.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "teste da unitv"}, "client_id": 6, "created_at": "2025-11-17T21:12:50.969568", "expires_at": "2025-11-18T21:12:50.968", "payment_token": "0db2ad7fece3055632b1d18c033a9b75", "session_token": "b46ddfbaf52c6b43c1b7cb28c02e55f963f96d31529b6f6e9792f75a3048e8f0", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:07.193825	\N	\N	\N
22	payment_sessions	DELETE	127	{"id": 127, "amount": 1.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "teste da unitv"}, "client_id": 6, "created_at": "2025-11-17T21:12:59.441555", "expires_at": "2025-11-18T21:12:59.441", "payment_token": "0db2ad7fece3055632b1d18c033a9b75", "session_token": "59a8e71ee075ad94a17da1cc2dae0d385db5d200f07dda50ed705bf53255266a", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:07.193825	\N	\N	\N
23	payment_sessions	DELETE	128	{"id": 128, "amount": 1.00, "status": "paid", "paid_at": "2025-11-17T21:13:53.889274", "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "teste da unitv"}, "client_id": 6, "created_at": "2025-11-17T21:13:33.880394", "expires_at": "2025-11-18T21:13:33.879", "payment_token": "0db2ad7fece3055632b1d18c033a9b75", "session_token": "fbf106f9ef8c5644f776f587074ac14768276128b2805167d783cd27f711f502", "payment_method": "bank_transfer", "mercadopago_init_point": null, "mercadopago_payment_id": "133648495833", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:07.193825	\N	\N	\N
24	payment_sessions	DELETE	129	{"id": 129, "amount": 1.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "teste da unitv"}, "client_id": 6, "created_at": "2025-11-17T21:13:57.421055", "expires_at": "2025-11-18T21:13:57.42", "payment_token": "0db2ad7fece3055632b1d18c033a9b75", "session_token": "f53d284429348c6055f1febc01ba48582c5f5b0f7a37886c62b24dfc55795b3e", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:07.193825	\N	\N	\N
25	payment_sessions	DELETE	130	{"id": 130, "amount": 1.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "teste da unitv"}, "client_id": 6, "created_at": "2025-11-17T21:21:24.095601", "expires_at": "2025-11-18T21:21:24.094", "payment_token": "0db2ad7fece3055632b1d18c033a9b75", "session_token": "8c6ab58796c7234fa7feb0ab51acec63a51bfee3db87c02b1c945544b7811f89", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:07.193825	\N	\N	\N
26	payment_sessions	DELETE	131	{"id": 131, "amount": 1.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "teste da unitv"}, "client_id": 6, "created_at": "2025-11-17T21:59:49.933179", "expires_at": "2025-11-18T21:59:49.932", "payment_token": "0db2ad7fece3055632b1d18c033a9b75", "session_token": "7fa157f157d0e0ac304a57ec500ad2a297ca7eba1b55d514c4a190818bbc9ca5", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:07.193825	\N	\N	\N
27	payment_sessions	DELETE	132	{"id": 132, "amount": 1.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "teste da unitv"}, "client_id": 6, "created_at": "2025-11-17T23:07:25.125782", "expires_at": "2025-11-18T23:07:25.125", "payment_token": "0db2ad7fece3055632b1d18c033a9b75", "session_token": "df19db0f31eeb2bd64f304f77e81b577dc39b2d7a3ac65dc7cc798b9db0f9db2", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:07.193825	\N	\N	\N
28	payment_sessions	DELETE	133	{"id": 133, "amount": 1.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "teste da unitv"}, "client_id": 6, "created_at": "2025-11-17T23:07:51.658393", "expires_at": "2025-11-18T23:07:51.657", "payment_token": "0db2ad7fece3055632b1d18c033a9b75", "session_token": "630ce24b1103f00d6e167808b92baf30a2c23dda26afbfb935e8b6b0695b329c", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:07.193825	\N	\N	\N
29	payment_sessions	DELETE	134	{"id": 134, "amount": 1.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "teste da unitv"}, "client_id": 6, "created_at": "2025-11-17T23:14:00.848763", "expires_at": "2025-11-18T23:14:00.848", "payment_token": "0db2ad7fece3055632b1d18c033a9b75", "session_token": "a8db4d2e5b4b1a4eec402e1082524abb3a9908d745a5422b06fdec783c31a2d7", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:07.193825	\N	\N	\N
30	payment_sessions	DELETE	135	{"id": 135, "amount": 1.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "teste da unitv"}, "client_id": 6, "created_at": "2025-11-17T23:14:08.696855", "expires_at": "2025-11-18T23:14:08.695", "payment_token": "0db2ad7fece3055632b1d18c033a9b75", "session_token": "99333c5f16c184e6472b91771ea21add89a3fe4884dd94a44cc36281282809dc", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:07.193825	\N	\N	\N
31	payment_sessions	DELETE	136	{"id": 136, "amount": 1.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "teste da unitv"}, "client_id": 6, "created_at": "2025-11-17T23:14:31.08859", "expires_at": "2025-11-18T23:14:31.087", "payment_token": "0db2ad7fece3055632b1d18c033a9b75", "session_token": "519690eb96f5ca3cb7898ab08053903e5588a241c1548e77d83c78d3a1a22c27", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:07.193825	\N	\N	\N
32	payment_sessions	DELETE	137	{"id": 137, "amount": 1.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "teste da unitv"}, "client_id": 6, "created_at": "2025-11-17T23:20:13.187391", "expires_at": "2025-11-18T23:20:13.183", "payment_token": "0db2ad7fece3055632b1d18c033a9b75", "session_token": "7c759a6c6e41b4fad03b9c8886db0cabff4c971d2e939920d55894b447fdec17", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:07.193825	\N	\N	\N
33	payment_sessions	DELETE	138	{"id": 138, "amount": 1.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "teste da unitv"}, "client_id": 6, "created_at": "2025-11-17T23:20:56.911652", "expires_at": "2025-11-18T23:20:56.911", "payment_token": "0db2ad7fece3055632b1d18c033a9b75", "session_token": "1e4629119ea6c261eb860a065a4ab23f635b3770be63074d4d19ddc47857b9fc", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:07.193825	\N	\N	\N
34	payment_sessions	DELETE	139	{"id": 139, "amount": 1.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "teste da unitv"}, "client_id": 6, "created_at": "2025-11-17T23:21:46.602087", "expires_at": "2025-11-18T23:21:46.601", "payment_token": "0db2ad7fece3055632b1d18c033a9b75", "session_token": "66f055dfcdaee4076bc7f85563ad73aa580b24594d4415dd584b68b85594c4a2", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:07.193825	\N	\N	\N
35	clients	DELETE	5	{"id": 5, "name": "cliente teste unitv", "notes": "", "plan_id": 17, "user_id": 2, "due_date": "2026-01-17", "password": "", "username": "", "is_active": true, "server_id": 2, "created_at": "2025-11-17T18:16:34.169911", "device_key": "", "updated_at": "2025-11-17T18:38:58.275529", "mac_address": "", "price_value": 10.00, "payment_token": "d9fe70e4d21ff78d3874d04308045e92", "whatsapp_number": "558594021963"}	\N	gestao_user	2025-11-18 23:35:12.824484	\N	\N	\N
152	clients	INSERT	15	\N	{"id": 15, "name": "oi", "notes": "", "plan_id": 6, "user_id": 2, "due_date": "2025-01-01", "password": "", "username": "", "is_active": true, "server_id": 2, "created_at": "2025-11-19T00:26:34.568282", "device_key": "", "updated_at": "2025-11-19T00:26:34.568282", "mac_address": "", "price_value": 1.00, "payment_token": "8b403b3379322e6fe064a83185248e22", "whatsapp_number": "558593028391"}	gestao_user	2025-11-19 00:26:34.568282	\N	\N	\N
36	financial_transactions	DELETE	80	{"id": 80, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2025-11-17", "client_id": 5, "paid_date": "2025-11-17T12:00:00", "created_at": "2025-11-17T18:17:34.597642", "net_profit": 7.00, "updated_at": "2025-11-17T18:17:34.597642", "server_cost": 3.00, "unitv_code_id": null, "payment_method": "bank_transfer", "amount_received": 10.00, "payment_gateway": "mercadopago", "gateway_payment_id": "134235354870", "payment_session_id": 81}	\N	gestao_user	2025-11-18 23:35:12.824484	\N	\N	\N
37	financial_transactions	DELETE	81	{"id": 81, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2025-12-17", "client_id": 5, "paid_date": "2025-11-17T18:38:58.291452", "created_at": "2025-11-17T18:38:58.291452", "net_profit": 7.00, "updated_at": "2025-11-17T18:38:58.291452", "server_cost": 3.00, "unitv_code_id": 7, "payment_method": "bank_transfer", "amount_received": 10.00, "payment_gateway": "mercadopago", "gateway_payment_id": "134236737968", "payment_session_id": 85}	\N	gestao_user	2025-11-18 23:35:12.824484	\N	\N	\N
38	payment_sessions	DELETE	81	{"id": 81, "amount": 10.00, "status": "paid", "paid_at": "2025-11-17T18:17:34.562121", "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 10, "card_amount": 11, "client_name": "cliente teste unitv"}, "client_id": 5, "created_at": "2025-11-17T18:16:42.882147", "expires_at": "2025-11-18T18:16:42.881", "payment_token": "d9fe70e4d21ff78d3874d04308045e92", "session_token": "17d8158a6ccb14e85f185da7799e2b82404a6ff81b66f1eb14a1cfb46a27b1f6", "payment_method": "bank_transfer", "mercadopago_init_point": null, "mercadopago_payment_id": "134235354870", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:12.824484	\N	\N	\N
39	payment_sessions	DELETE	84	{"id": 84, "amount": 10.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 10, "card_amount": 11, "client_name": "cliente teste unitv"}, "client_id": 5, "created_at": "2025-11-17T18:31:08.27402", "expires_at": "2025-11-18T18:31:08.273", "payment_token": "d9fe70e4d21ff78d3874d04308045e92", "session_token": "5c3a6cffc4d46ddedf7549251bca84472f7251c4366bc2a190d2d59610b0db16", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:12.824484	\N	\N	\N
40	payment_sessions	DELETE	85	{"id": 85, "amount": 10.00, "status": "paid", "paid_at": "2025-11-17T18:38:58.272878", "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 10, "card_amount": 11, "client_name": "cliente teste unitv"}, "client_id": 5, "created_at": "2025-11-17T18:37:25.691373", "expires_at": "2025-11-18T18:37:25.69", "payment_token": "d9fe70e4d21ff78d3874d04308045e92", "session_token": "c62c5dca0a9b03cd41b4df977c5dcf935abe6825bc1ad26f2d6d0eb4b9df058f", "payment_method": "bank_transfer", "mercadopago_init_point": null, "mercadopago_payment_id": "134236737968", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:12.824484	\N	\N	\N
41	payment_sessions	DELETE	86	{"id": 86, "amount": 10.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 10, "card_amount": 11, "client_name": "cliente teste unitv"}, "client_id": 5, "created_at": "2025-11-17T18:45:15.025666", "expires_at": "2025-11-18T18:45:15.024", "payment_token": "d9fe70e4d21ff78d3874d04308045e92", "session_token": "508310353465044f771c6a8692a1b4d26ad48c8dda7bf99a783ba3a0391a0d51", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": "134238625430", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:12.824484	\N	\N	\N
42	payment_sessions	DELETE	88	{"id": 88, "amount": 10.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 10, "card_amount": 11, "client_name": "cliente teste unitv"}, "client_id": 5, "created_at": "2025-11-17T18:50:42.564978", "expires_at": "2025-11-18T18:50:42.562", "payment_token": "d9fe70e4d21ff78d3874d04308045e92", "session_token": "1d36a472f5a0a52379053323765ed4dd81ae91c4617d889f81d90cd0154ffef0", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": "133630295513", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:12.824484	\N	\N	\N
43	payment_sessions	DELETE	89	{"id": 89, "amount": 10.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 10, "card_amount": 11, "client_name": "cliente teste unitv"}, "client_id": 5, "created_at": "2025-11-17T18:59:22.717383", "expires_at": "2025-11-18T18:59:22.716", "payment_token": "d9fe70e4d21ff78d3874d04308045e92", "session_token": "89234ed9a7ff96873d167c8387b1ea0bf43b0599682eb1692a6c03d3ce25db14", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:12.824484	\N	\N	\N
44	payment_sessions	DELETE	90	{"id": 90, "amount": 10.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 10, "card_amount": 11, "client_name": "cliente teste unitv"}, "client_id": 5, "created_at": "2025-11-17T18:59:36.525108", "expires_at": "2025-11-18T18:59:36.524", "payment_token": "d9fe70e4d21ff78d3874d04308045e92", "session_token": "f9873de27ba1a071ab12d284c025e51c0244dc146dbeb308587314d7d2544ea4", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:12.824484	\N	\N	\N
45	payment_sessions	DELETE	91	{"id": 91, "amount": 10.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 10, "card_amount": 11, "client_name": "cliente teste unitv"}, "client_id": 5, "created_at": "2025-11-17T19:00:06.906486", "expires_at": "2025-11-18T19:00:06.905", "payment_token": "d9fe70e4d21ff78d3874d04308045e92", "session_token": "ba06418b0c82eb32be8b8088a113c75b780f024eac4816c29ef8e39bfc337f55", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:12.824484	\N	\N	\N
46	payment_sessions	DELETE	92	{"id": 92, "amount": 10.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 10, "card_amount": 11, "client_name": "cliente teste unitv"}, "client_id": 5, "created_at": "2025-11-17T19:03:01.090754", "expires_at": "2025-11-18T19:03:01.09", "payment_token": "d9fe70e4d21ff78d3874d04308045e92", "session_token": "317c495c45e151bc2cafc914c2dde3885e2d351f7ef149e55380089c6eec96d4", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:12.824484	\N	\N	\N
47	payment_sessions	DELETE	93	{"id": 93, "amount": 10.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 10, "card_amount": 11, "client_name": "cliente teste unitv"}, "client_id": 5, "created_at": "2025-11-17T19:03:26.652712", "expires_at": "2025-11-18T19:03:26.651", "payment_token": "d9fe70e4d21ff78d3874d04308045e92", "session_token": "f65a07bb8ff572fe778c86bd07f17fecae7a8f713cbb222c263d5cf0999d1a2e", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:12.824484	\N	\N	\N
48	payment_sessions	DELETE	94	{"id": 94, "amount": 10.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 10, "card_amount": 11, "client_name": "cliente teste unitv"}, "client_id": 5, "created_at": "2025-11-17T19:03:47.93889", "expires_at": "2025-11-18T19:03:47.938", "payment_token": "d9fe70e4d21ff78d3874d04308045e92", "session_token": "f25b90f91e42a33ca212261bb633393cf9a1f1e778c639e670f0118a65e12d70", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:12.824484	\N	\N	\N
49	payment_sessions	DELETE	95	{"id": 95, "amount": 10.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 10, "card_amount": 11, "client_name": "cliente teste unitv"}, "client_id": 5, "created_at": "2025-11-17T19:04:48.845754", "expires_at": "2025-11-18T19:04:48.844", "payment_token": "d9fe70e4d21ff78d3874d04308045e92", "session_token": "fb79c06ccdcec069a8b1d23c737ba3d5991dcceb116c16e1e6c5237b988ea3a9", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:12.824484	\N	\N	\N
50	payment_sessions	DELETE	97	{"id": 97, "amount": 10.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 10, "card_amount": 11, "client_name": "cliente teste unitv"}, "client_id": 5, "created_at": "2025-11-17T19:07:35.609084", "expires_at": "2025-11-18T19:07:35.608", "payment_token": "d9fe70e4d21ff78d3874d04308045e92", "session_token": "04977d8fdc2c6a381a4f90ee5d955afbb68f515554f5f5b35f87df487653ffe4", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:12.824484	\N	\N	\N
51	payment_sessions	DELETE	98	{"id": 98, "amount": 10.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 10, "card_amount": 11, "client_name": "cliente teste unitv"}, "client_id": 5, "created_at": "2025-11-17T19:07:45.135787", "expires_at": "2025-11-18T19:07:45.134", "payment_token": "d9fe70e4d21ff78d3874d04308045e92", "session_token": "324e68f0f700d972af5a0563945a8c4acc70f966a879916c2ca81b0e398ee1ff", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:12.824484	\N	\N	\N
52	payment_sessions	DELETE	99	{"id": 99, "amount": 10.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 10, "card_amount": 11, "client_name": "cliente teste unitv"}, "client_id": 5, "created_at": "2025-11-17T19:07:56.991559", "expires_at": "2025-11-18T19:07:56.99", "payment_token": "d9fe70e4d21ff78d3874d04308045e92", "session_token": "7c463b0d07da31629e288da3b124872716619dc258ebef5db7bf420e0b8016d5", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:12.824484	\N	\N	\N
53	payment_sessions	DELETE	100	{"id": 100, "amount": 10.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 10, "card_amount": 11, "client_name": "cliente teste unitv"}, "client_id": 5, "created_at": "2025-11-17T19:08:03.476416", "expires_at": "2025-11-18T19:08:03.475", "payment_token": "d9fe70e4d21ff78d3874d04308045e92", "session_token": "0895d9f6d8785f587ee837869a6aad49e35e58628e3956ac2163be4c0852faae", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:12.824484	\N	\N	\N
54	payment_sessions	DELETE	102	{"id": 102, "amount": 10.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 10, "card_amount": 11, "client_name": "cliente teste unitv"}, "client_id": 5, "created_at": "2025-11-17T19:08:54.886825", "expires_at": "2025-11-18T19:08:54.886", "payment_token": "d9fe70e4d21ff78d3874d04308045e92", "session_token": "5eab04998c520225a7095f53cb7fb0d513ca308d1d6b95442015d2f4e013c3bb", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:12.824484	\N	\N	\N
55	payment_sessions	DELETE	105	{"id": 105, "amount": 10.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 10, "card_amount": 11, "client_name": "cliente teste unitv"}, "client_id": 5, "created_at": "2025-11-17T19:11:16.452579", "expires_at": "2025-11-18T19:11:16.451", "payment_token": "d9fe70e4d21ff78d3874d04308045e92", "session_token": "574c8ade4a0c7669d659f2c2f1966e1c4f2fff0f76ebb7e1b967d0b9960f801e", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:12.824484	\N	\N	\N
56	payment_sessions	DELETE	106	{"id": 106, "amount": 10.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 10, "card_amount": 11, "client_name": "cliente teste unitv"}, "client_id": 5, "created_at": "2025-11-17T19:15:22.871971", "expires_at": "2025-11-18T19:15:22.871", "payment_token": "d9fe70e4d21ff78d3874d04308045e92", "session_token": "ac26d4115c750f6aa50495dee09b9824a3d8ffe29bc808c64f972af14d84cf61", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:12.824484	\N	\N	\N
57	payment_sessions	DELETE	107	{"id": 107, "amount": 10.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 10, "card_amount": 11, "client_name": "cliente teste unitv"}, "client_id": 5, "created_at": "2025-11-17T19:15:33.342114", "expires_at": "2025-11-18T19:15:33.34", "payment_token": "d9fe70e4d21ff78d3874d04308045e92", "session_token": "d794a50a779933e42fa233187eba540931309bc7612011eb9a100658032ea5f1", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:12.824484	\N	\N	\N
58	payment_sessions	DELETE	108	{"id": 108, "amount": 10.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 10, "card_amount": 11, "client_name": "cliente teste unitv"}, "client_id": 5, "created_at": "2025-11-17T19:16:18.737043", "expires_at": "2025-11-18T19:16:18.735", "payment_token": "d9fe70e4d21ff78d3874d04308045e92", "session_token": "2f79c043dd9753f3997b5411cbf82b3e5ad4e730a6122777d7284ce3a62d0552", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:12.824484	\N	\N	\N
59	payment_sessions	DELETE	109	{"id": 109, "amount": 10.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 10, "card_amount": 11, "client_name": "cliente teste unitv"}, "client_id": 5, "created_at": "2025-11-17T19:17:03.644938", "expires_at": "2025-11-18T19:17:03.643", "payment_token": "d9fe70e4d21ff78d3874d04308045e92", "session_token": "1be98cc6ca3e0f7b1d824dccbf58438687df03663436f142832a14ec8bfa6577", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:12.824484	\N	\N	\N
60	payment_sessions	DELETE	110	{"id": 110, "amount": 10.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 10, "card_amount": 11, "client_name": "cliente teste unitv"}, "client_id": 5, "created_at": "2025-11-17T19:58:48.887045", "expires_at": "2025-11-18T19:58:48.885", "payment_token": "d9fe70e4d21ff78d3874d04308045e92", "session_token": "892d81aaa8a033f6129421018c94cc0e2fd9262662c74bbd90558748591f013d", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:12.824484	\N	\N	\N
61	payment_sessions	DELETE	112	{"id": 112, "amount": 10.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 10, "card_amount": 11, "client_name": "cliente teste unitv"}, "client_id": 5, "created_at": "2025-11-17T20:32:32.119663", "expires_at": "2025-11-18T20:32:32.118", "payment_token": "d9fe70e4d21ff78d3874d04308045e92", "session_token": "f49aed1725e402c24bd4edc2e78d9a25d4db1aa3258296654eabf19a204213e7", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:12.824484	\N	\N	\N
62	payment_sessions	DELETE	113	{"id": 113, "amount": 10.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 10, "card_amount": 11, "client_name": "cliente teste unitv"}, "client_id": 5, "created_at": "2025-11-17T20:34:58.532085", "expires_at": "2025-11-18T20:34:58.531", "payment_token": "d9fe70e4d21ff78d3874d04308045e92", "session_token": "7d4ea15fa058bbdcd7c96ba5f4ab8b4cfc5f6b3bfd35bfa2ac1bf807c052b6c0", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:12.824484	\N	\N	\N
63	payment_sessions	DELETE	114	{"id": 114, "amount": 10.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 10, "card_amount": 11, "client_name": "cliente teste unitv"}, "client_id": 5, "created_at": "2025-11-17T20:37:09.301171", "expires_at": "2025-11-18T20:37:09.299", "payment_token": "d9fe70e4d21ff78d3874d04308045e92", "session_token": "967d9897cdc873d36c9f489550cf3183f4026207956412656c854d23234dd966", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:12.824484	\N	\N	\N
64	payment_sessions	DELETE	115	{"id": 115, "amount": 10.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 10, "card_amount": 11, "client_name": "cliente teste unitv"}, "client_id": 5, "created_at": "2025-11-17T20:37:59.483818", "expires_at": "2025-11-18T20:37:59.481", "payment_token": "d9fe70e4d21ff78d3874d04308045e92", "session_token": "71633aba26b7f73c180e62e9650865f8fb6aae68bc87aaa334104a0134454a26", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:12.824484	\N	\N	\N
65	payment_sessions	DELETE	116	{"id": 116, "amount": 10.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 10, "card_amount": 11, "client_name": "cliente teste unitv"}, "client_id": 5, "created_at": "2025-11-17T20:41:39.838257", "expires_at": "2025-11-18T20:41:39.836", "payment_token": "d9fe70e4d21ff78d3874d04308045e92", "session_token": "7c474120de49ef4534cd23d8b6eddf48c5b5dde18993a8baeb138e7a6a4ecde5", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:12.824484	\N	\N	\N
66	payment_sessions	DELETE	117	{"id": 117, "amount": 10.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 10, "card_amount": 11, "client_name": "cliente teste unitv"}, "client_id": 5, "created_at": "2025-11-17T20:44:01.995328", "expires_at": "2025-11-18T20:44:01.993", "payment_token": "d9fe70e4d21ff78d3874d04308045e92", "session_token": "25abe452473890a1726eeeacbd25b36025463218aa0466956de65278c301b3fe", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:12.824484	\N	\N	\N
67	payment_sessions	DELETE	118	{"id": 118, "amount": 10.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 10, "card_amount": 11, "client_name": "cliente teste unitv"}, "client_id": 5, "created_at": "2025-11-17T20:44:06.125234", "expires_at": "2025-11-18T20:44:06.124", "payment_token": "d9fe70e4d21ff78d3874d04308045e92", "session_token": "f1deebbe8b5460b616e5812930849bc4af4f1acc222b1546e35a6d67d6d761e2", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:12.824484	\N	\N	\N
68	payment_sessions	DELETE	119	{"id": 119, "amount": 10.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 10, "card_amount": 11, "client_name": "cliente teste unitv"}, "client_id": 5, "created_at": "2025-11-17T20:45:40.016987", "expires_at": "2025-11-18T20:45:40.015", "payment_token": "d9fe70e4d21ff78d3874d04308045e92", "session_token": "9ac00266ab9e1b8e090e1d46b29338bdac373ffcc4a103394ab54351bc9a7584", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:12.824484	\N	\N	\N
69	payment_sessions	DELETE	120	{"id": 120, "amount": 10.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 10, "card_amount": 11, "client_name": "cliente teste unitv"}, "client_id": 5, "created_at": "2025-11-17T20:47:09.483472", "expires_at": "2025-11-18T20:47:09.482", "payment_token": "d9fe70e4d21ff78d3874d04308045e92", "session_token": "ed73cb81bf65688202a57ec89b1a6a075a97e4872130adf5b27b7e1fbe25e80e", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:12.824484	\N	\N	\N
70	clients	DELETE	2	{"id": 2, "name": "sinha moca", "notes": "", "plan_id": 16, "user_id": 2, "due_date": "2026-07-01", "password": "", "username": "069992502", "is_active": true, "server_id": 1, "created_at": "2025-10-29T01:13:55.226082", "device_key": "", "updated_at": "2025-11-07T22:56:08.807429", "mac_address": "", "price_value": 1.00, "payment_token": "330a16a453c03ea30ce24afc52082d09", "whatsapp_number": "5585994021963"}	\N	gestao_user	2025-11-18 23:35:17.026991	\N	\N	\N
71	financial_transactions	DELETE	14	{"id": 14, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2025-10-28", "client_id": 2, "paid_date": "2025-10-31T12:00:00", "created_at": "2025-10-31T23:34:33.448963", "net_profit": -1.00, "updated_at": "2025-10-31T23:34:33.448963", "server_cost": 2.00, "unitv_code_id": null, "payment_method": "bank_transfer", "amount_received": 1.00, "payment_gateway": "mercadopago", "gateway_payment_id": "131450991357", "payment_session_id": 15}	\N	gestao_user	2025-11-18 23:35:17.026991	\N	\N	\N
72	financial_transactions	DELETE	15	{"id": 15, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2025-12-01", "client_id": 2, "paid_date": "2025-10-31T12:00:00", "created_at": "2025-10-31T23:44:34.347849", "net_profit": -1.00, "updated_at": "2025-10-31T23:44:34.347849", "server_cost": 2.00, "unitv_code_id": null, "payment_method": "bank_transfer", "amount_received": 1.00, "payment_gateway": "mercadopago", "gateway_payment_id": "131451919359", "payment_session_id": 16}	\N	gestao_user	2025-11-18 23:35:17.026991	\N	\N	\N
73	financial_transactions	DELETE	16	{"id": 16, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2026-01-01", "client_id": 2, "paid_date": "2025-10-31T12:00:00", "created_at": "2025-10-31T23:47:59.95976", "net_profit": -1.00, "updated_at": "2025-10-31T23:47:59.95976", "server_cost": 2.00, "unitv_code_id": null, "payment_method": "bank_transfer", "amount_received": 1.00, "payment_gateway": "mercadopago", "gateway_payment_id": "131451025879", "payment_session_id": 17}	\N	gestao_user	2025-11-18 23:35:17.026991	\N	\N	\N
74	financial_transactions	DELETE	17	{"id": 17, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2026-02-01", "client_id": 2, "paid_date": "2025-11-05T12:00:00", "created_at": "2025-11-05T17:23:34.548056", "net_profit": -1.00, "updated_at": "2025-11-05T17:23:34.548056", "server_cost": 2.00, "unitv_code_id": null, "payment_method": "bank_transfer", "amount_received": 1.00, "payment_gateway": "mercadopago", "gateway_payment_id": "132632264176", "payment_session_id": 20}	\N	gestao_user	2025-11-18 23:35:17.026991	\N	\N	\N
75	financial_transactions	DELETE	18	{"id": 18, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2026-03-01", "client_id": 2, "paid_date": "2025-11-05T12:00:00", "created_at": "2025-11-05T17:25:24.793945", "net_profit": -1.00, "updated_at": "2025-11-05T17:25:24.793945", "server_cost": 2.00, "unitv_code_id": null, "payment_method": "bank_transfer", "amount_received": 1.00, "payment_gateway": "mercadopago", "gateway_payment_id": "132031828777", "payment_session_id": 21}	\N	gestao_user	2025-11-18 23:35:17.026991	\N	\N	\N
76	financial_transactions	DELETE	19	{"id": 19, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2026-04-01", "client_id": 2, "paid_date": "2025-11-05T12:00:00", "created_at": "2025-11-05T17:33:21.296767", "net_profit": -1.00, "updated_at": "2025-11-05T17:33:21.296767", "server_cost": 2.00, "unitv_code_id": null, "payment_method": "bank_transfer", "amount_received": 1.00, "payment_gateway": "mercadopago", "gateway_payment_id": "132031645599", "payment_session_id": 22}	\N	gestao_user	2025-11-18 23:35:17.026991	\N	\N	\N
77	financial_transactions	DELETE	20	{"id": 20, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2026-05-01", "client_id": 2, "paid_date": "2025-11-05T12:00:00", "created_at": "2025-11-05T18:25:27.195363", "net_profit": -1.00, "updated_at": "2025-11-05T18:25:27.195363", "server_cost": 2.00, "unitv_code_id": null, "payment_method": "bank_transfer", "amount_received": 1.00, "payment_gateway": "mercadopago", "gateway_payment_id": "132039743947", "payment_session_id": 23}	\N	gestao_user	2025-11-18 23:35:17.026991	\N	\N	\N
78	financial_transactions	DELETE	27	{"id": 27, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2026-05-01", "client_id": 2, "paid_date": "2025-11-05T12:00:00", "created_at": "2025-11-05T23:14:22.800942", "net_profit": -1.00, "updated_at": "2025-11-05T23:14:22.800942", "server_cost": 2.00, "unitv_code_id": null, "payment_method": "bank_transfer", "amount_received": 1.00, "payment_gateway": "mercadopago", "gateway_payment_id": "132678169030", "payment_session_id": 30}	\N	gestao_user	2025-11-18 23:35:17.026991	\N	\N	\N
79	financial_transactions	DELETE	29	{"id": 29, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2026-07-01", "client_id": 2, "paid_date": "2025-11-07T12:00:00", "created_at": "2025-11-07T14:16:30.775496", "net_profit": -1.00, "updated_at": "2025-11-07T14:16:30.775496", "server_cost": 2.00, "unitv_code_id": null, "payment_method": "pix", "amount_received": 1.00, "payment_gateway": null, "gateway_payment_id": null, "payment_session_id": null}	\N	gestao_user	2025-11-18 23:35:17.026991	\N	\N	\N
80	payment_sessions	DELETE	30	{"id": 30, "amount": 1.00, "status": "paid", "paid_at": "2025-11-05T23:14:22.524515", "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "sinha moca"}, "client_id": 2, "created_at": "2025-11-05T23:14:05.739858", "expires_at": "2025-11-06T23:14:05.739", "payment_token": "330a16a453c03ea30ce24afc52082d09", "session_token": "4d939f7dd4a2ff21d4d1326fd97cf98f69f103dfb29f834d550def77f4926079", "payment_method": "bank_transfer", "mercadopago_init_point": null, "mercadopago_payment_id": "132678169030", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:17.026991	\N	\N	\N
81	payment_sessions	DELETE	10	{"id": 10, "amount": 1.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "cliente de teste"}, "client_id": 2, "created_at": "2025-10-28T22:59:11.734722", "expires_at": "2025-10-29T22:59:11.733", "payment_token": "330a16a453c03ea30ce24afc52082d09", "session_token": "40f0e71297707efc53345591dd7ad8b7b5c52d5d960648845cda8d3a9c92ea90", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:17.026991	\N	\N	\N
82	payment_sessions	DELETE	11	{"id": 11, "amount": 1.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "cliente de teste"}, "client_id": 2, "created_at": "2025-10-28T23:00:01.851226", "expires_at": "2025-10-29T23:00:01.847", "payment_token": "330a16a453c03ea30ce24afc52082d09", "session_token": "eb0fcf9ddcdcc44880ad801a710423734ddbf35c66f520d4726600fdbad56bb7", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:17.026991	\N	\N	\N
83	payment_sessions	DELETE	12	{"id": 12, "amount": 1.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "cliente de teste koffice"}, "client_id": 2, "created_at": "2025-10-31T23:23:16.629904", "expires_at": "2025-11-01T23:23:16.628", "payment_token": "330a16a453c03ea30ce24afc52082d09", "session_token": "0ccbec8e92f8acda1eddb15cd1871e17f8ac7160222580e53af09d87f0f39663", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": "131449953545", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:17.026991	\N	\N	\N
84	payment_sessions	DELETE	13	{"id": 13, "amount": 1.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "cliente de teste koffice"}, "client_id": 2, "created_at": "2025-10-31T23:30:08.208373", "expires_at": "2025-11-01T23:30:08.207", "payment_token": "330a16a453c03ea30ce24afc52082d09", "session_token": "0670b6045bfa4f9069e09bab77383cad85d5abd59d578d8929946ca258027203", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": "131450501437", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:17.026991	\N	\N	\N
85	payment_sessions	DELETE	14	{"id": 14, "amount": 1.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "cliente de teste koffice"}, "client_id": 2, "created_at": "2025-10-31T23:32:16.93137", "expires_at": "2025-11-01T23:32:16.93", "payment_token": "330a16a453c03ea30ce24afc52082d09", "session_token": "64bee1dfce571281aed383fee7adde0d2c7c2b447733ff77a1e89ed2322f0d25", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": "131450411711", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:17.026991	\N	\N	\N
86	payment_sessions	DELETE	15	{"id": 15, "amount": 1.00, "status": "paid", "paid_at": "2025-10-31T23:34:32.195625", "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "cliente de teste koffice"}, "client_id": 2, "created_at": "2025-10-31T23:34:11.400151", "expires_at": "2025-11-01T23:34:11.398", "payment_token": "330a16a453c03ea30ce24afc52082d09", "session_token": "d415e8ff52feb4818019cc6577d6ded5ff9fc8e7338033c7ade1b62d63ff2134", "payment_method": "bank_transfer", "mercadopago_init_point": null, "mercadopago_payment_id": "131450991357", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:17.026991	\N	\N	\N
87	payment_sessions	DELETE	16	{"id": 16, "amount": 1.00, "status": "paid", "paid_at": "2025-10-31T23:44:33.731247", "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "cliente de teste koffice"}, "client_id": 2, "created_at": "2025-10-31T23:44:16.759404", "expires_at": "2025-11-01T23:44:16.758", "payment_token": "330a16a453c03ea30ce24afc52082d09", "session_token": "ad3060178d7b5504c96c5399c14be6d29a4e947fb85552c4e33ae2911f3b8882", "payment_method": "bank_transfer", "mercadopago_init_point": null, "mercadopago_payment_id": "131451919359", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:17.026991	\N	\N	\N
88	payment_sessions	DELETE	17	{"id": 17, "amount": 1.00, "status": "paid", "paid_at": "2025-10-31T23:47:20.728516", "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "cliente de teste koffice"}, "client_id": 2, "created_at": "2025-10-31T23:46:57.963457", "expires_at": "2025-11-01T23:46:57.962", "payment_token": "330a16a453c03ea30ce24afc52082d09", "session_token": "faa1176ed6e916ec767c9088f748a76e8011eee28ee9b69b7d23de47e1997afd", "payment_method": "bank_transfer", "mercadopago_init_point": null, "mercadopago_payment_id": "131451025879", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:17.026991	\N	\N	\N
89	payment_sessions	DELETE	18	{"id": 18, "amount": 1.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "cliente de teste koffice"}, "client_id": 2, "created_at": "2025-10-31T23:48:41.298921", "expires_at": "2025-11-01T23:48:41.294", "payment_token": "330a16a453c03ea30ce24afc52082d09", "session_token": "680f863745dfade6c59d47e53a039a64afc395da441f60d021b43710255d1f5b", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:17.026991	\N	\N	\N
90	payment_sessions	DELETE	19	{"id": 19, "amount": 1.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "cliente de teste koffice"}, "client_id": 2, "created_at": "2025-11-05T13:48:22.397127", "expires_at": "2025-11-06T13:48:22.395", "payment_token": "330a16a453c03ea30ce24afc52082d09", "session_token": "88ea03626610affdd90de1e38148f2b7fbf9e6efe2d7765988ea8c1e664796fd", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": "132004581079", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:17.026991	\N	\N	\N
91	payment_sessions	DELETE	20	{"id": 20, "amount": 1.00, "status": "paid", "paid_at": "2025-11-05T17:23:34.530068", "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "sinha moca"}, "client_id": 2, "created_at": "2025-11-05T17:22:44.237755", "expires_at": "2025-11-06T17:22:44.233", "payment_token": "330a16a453c03ea30ce24afc52082d09", "session_token": "2e4c29fe9ba370fedd5dc71f453c56a13963ce2ab7c8b78970273cd191d4f44d", "payment_method": "bank_transfer", "mercadopago_init_point": null, "mercadopago_payment_id": "132632264176", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:17.026991	\N	\N	\N
92	payment_sessions	DELETE	21	{"id": 21, "amount": 1.00, "status": "paid", "paid_at": "2025-11-05T17:25:24.777318", "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "sinha moca"}, "client_id": 2, "created_at": "2025-11-05T17:25:07.034772", "expires_at": "2025-11-06T17:25:07.034", "payment_token": "330a16a453c03ea30ce24afc52082d09", "session_token": "f2196f827531e82b855f5dff19606f6f3ef6e3de4e31531f770779c6114db7d3", "payment_method": "bank_transfer", "mercadopago_init_point": null, "mercadopago_payment_id": "132031828777", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:17.026991	\N	\N	\N
93	payment_sessions	DELETE	22	{"id": 22, "amount": 1.00, "status": "paid", "paid_at": "2025-11-05T17:33:21.282162", "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "sinha moca"}, "client_id": 2, "created_at": "2025-11-05T17:32:55.189733", "expires_at": "2025-11-06T17:32:55.181", "payment_token": "330a16a453c03ea30ce24afc52082d09", "session_token": "eee219b1edd8baa47d987d4ffff6caf6f26e76c399c367c2e774475bc0aae683", "payment_method": "bank_transfer", "mercadopago_init_point": null, "mercadopago_payment_id": "132031645599", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:17.026991	\N	\N	\N
94	payment_sessions	DELETE	23	{"id": 23, "amount": 1.00, "status": "paid", "paid_at": "2025-11-05T18:25:27.182715", "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "sinha moca"}, "client_id": 2, "created_at": "2025-11-05T18:24:58.21898", "expires_at": "2025-11-06T18:24:58.217", "payment_token": "330a16a453c03ea30ce24afc52082d09", "session_token": "cf0c64287687d7d36e946e804bad5db999fe0633950b9da7cff70de138cd84d6", "payment_method": "bank_transfer", "mercadopago_init_point": null, "mercadopago_payment_id": "132039743947", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:35:17.026991	\N	\N	\N
96	clients	DELETE	3	{"id": 3, "name": "Heliton Fernando", "notes": "", "plan_id": 17, "user_id": 2, "due_date": "2026-10-15", "password": "", "username": ".", "is_active": true, "server_id": 1, "created_at": "2025-11-05T18:41:42.913442", "device_key": "", "updated_at": "2025-11-17T17:14:53.222932", "mac_address": "", "price_value": 1.00, "payment_token": "9659b149bb30d6b85f43923733a3ee87", "whatsapp_number": "558594021963"}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
97	financial_transactions	DELETE	21	{"id": 21, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2025-11-05", "client_id": 3, "paid_date": "2025-11-05T12:00:00", "created_at": "2025-11-05T18:42:20.605508", "net_profit": -1.00, "updated_at": "2025-11-05T18:42:20.605508", "server_cost": 2.00, "unitv_code_id": null, "payment_method": "bank_transfer", "amount_received": 1.00, "payment_gateway": "mercadopago", "gateway_payment_id": "132643426988", "payment_session_id": 24}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
98	financial_transactions	DELETE	22	{"id": 22, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2025-12-05", "client_id": 3, "paid_date": "2025-11-05T12:00:00", "created_at": "2025-11-05T18:47:48.823679", "net_profit": -1.00, "updated_at": "2025-11-05T18:47:48.823679", "server_cost": 2.00, "unitv_code_id": null, "payment_method": "bank_transfer", "amount_received": 1.00, "payment_gateway": "mercadopago", "gateway_payment_id": "132643711432", "payment_session_id": 25}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
99	financial_transactions	DELETE	23	{"id": 23, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2026-01-05", "client_id": 3, "paid_date": "2025-11-05T12:00:00", "created_at": "2025-11-05T19:00:25.916161", "net_profit": -1.00, "updated_at": "2025-11-05T19:00:25.916161", "server_cost": 2.00, "unitv_code_id": null, "payment_method": "bank_transfer", "amount_received": 1.00, "payment_gateway": "mercadopago", "gateway_payment_id": "132647338176", "payment_session_id": 26}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
100	financial_transactions	DELETE	24	{"id": 24, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2026-02-05", "client_id": 3, "paid_date": "2025-11-05T12:00:00", "created_at": "2025-11-05T19:06:42.026316", "net_profit": -1.00, "updated_at": "2025-11-05T19:06:42.026316", "server_cost": 2.00, "unitv_code_id": null, "payment_method": "bank_transfer", "amount_received": 1.00, "payment_gateway": "mercadopago", "gateway_payment_id": "132045961963", "payment_session_id": 27}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
101	financial_transactions	DELETE	25	{"id": 25, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2026-03-05", "client_id": 3, "paid_date": "2025-11-05T12:00:00", "created_at": "2025-11-05T23:02:32.807979", "net_profit": -1.00, "updated_at": "2025-11-05T23:02:32.807979", "server_cost": 2.00, "unitv_code_id": null, "payment_method": "bank_transfer", "amount_received": 1.00, "payment_gateway": "mercadopago", "gateway_payment_id": "132677920662", "payment_session_id": 28}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
102	financial_transactions	DELETE	26	{"id": 26, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2026-04-05", "client_id": 3, "paid_date": "2025-11-05T12:00:00", "created_at": "2025-11-05T23:11:33.209879", "net_profit": -1.00, "updated_at": "2025-11-05T23:11:33.209879", "server_cost": 2.00, "unitv_code_id": null, "payment_method": "bank_transfer", "amount_received": 1.00, "payment_gateway": "mercadopago", "gateway_payment_id": "132678836386", "payment_session_id": 29}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
103	financial_transactions	DELETE	28	{"id": 28, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2026-05-05", "client_id": 3, "paid_date": "2025-11-05T12:00:00", "created_at": "2025-11-05T23:19:33.356417", "net_profit": -1.00, "updated_at": "2025-11-05T23:19:33.356417", "server_cost": 2.00, "unitv_code_id": null, "payment_method": "bank_transfer", "amount_received": 1.00, "payment_gateway": "mercadopago", "gateway_payment_id": "132078802959", "payment_session_id": 31}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
104	financial_transactions	DELETE	30	{"id": 30, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2026-07-05", "client_id": 3, "paid_date": "2025-11-07T12:00:00", "created_at": "2025-11-07T14:26:38.804721", "net_profit": -1.00, "updated_at": "2025-11-07T14:26:38.804721", "server_cost": 2.00, "unitv_code_id": null, "payment_method": "pix", "amount_received": 1.00, "payment_gateway": null, "gateway_payment_id": null, "payment_session_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
105	financial_transactions	DELETE	31	{"id": 31, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2026-08-05", "client_id": 3, "paid_date": "2025-11-07T12:00:00", "created_at": "2025-11-07T14:27:12.188256", "net_profit": -1.00, "updated_at": "2025-11-07T14:27:12.188256", "server_cost": 2.00, "unitv_code_id": null, "payment_method": "pix", "amount_received": 1.00, "payment_gateway": null, "gateway_payment_id": null, "payment_session_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
106	financial_transactions	DELETE	32	{"id": 32, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2026-09-05", "client_id": 3, "paid_date": "2025-11-07T12:00:00", "created_at": "2025-11-07T14:27:33.281089", "net_profit": -1.00, "updated_at": "2025-11-07T14:27:33.281089", "server_cost": 2.00, "unitv_code_id": null, "payment_method": "pix", "amount_received": 1.00, "payment_gateway": null, "gateway_payment_id": null, "payment_session_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
107	financial_transactions	DELETE	33	{"id": 33, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2026-10-05", "client_id": 3, "paid_date": "2025-11-07T12:00:00", "created_at": "2025-11-07T14:28:17.204485", "net_profit": -1.00, "updated_at": "2025-11-07T14:28:17.204485", "server_cost": 2.00, "unitv_code_id": null, "payment_method": "pix", "amount_received": 1.00, "payment_gateway": null, "gateway_payment_id": null, "payment_session_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
108	financial_transactions	DELETE	34	{"id": 34, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2026-11-05", "client_id": 3, "paid_date": "2025-11-07T12:00:00", "created_at": "2025-11-07T16:38:46.267731", "net_profit": -1.00, "updated_at": "2025-11-07T16:38:46.267731", "server_cost": 2.00, "unitv_code_id": null, "payment_method": "pix", "amount_received": 1.00, "payment_gateway": null, "gateway_payment_id": null, "payment_session_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
109	financial_transactions	DELETE	35	{"id": 35, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2026-12-05", "client_id": 3, "paid_date": "2025-11-07T12:00:00", "created_at": "2025-11-07T16:39:03.126466", "net_profit": -1.00, "updated_at": "2025-11-07T16:39:03.126466", "server_cost": 2.00, "unitv_code_id": null, "payment_method": "pix", "amount_received": 1.00, "payment_gateway": null, "gateway_payment_id": null, "payment_session_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
110	financial_transactions	DELETE	37	{"id": 37, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2025-11-13", "client_id": 3, "paid_date": "2025-11-15T12:00:00", "created_at": "2025-11-15T23:09:24.780407", "net_profit": -1.00, "updated_at": "2025-11-15T23:09:24.780407", "server_cost": 2.00, "unitv_code_id": null, "payment_method": "bank_transfer", "amount_received": 1.00, "payment_gateway": "mercadopago", "gateway_payment_id": "133433233403", "payment_session_id": 33}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
111	financial_transactions	DELETE	38	{"id": 38, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2025-12-15", "client_id": 3, "paid_date": "2025-11-16T12:00:00", "created_at": "2025-11-16T23:17:30.173551", "net_profit": -1.00, "updated_at": "2025-11-16T23:17:30.173551", "server_cost": 2.00, "unitv_code_id": null, "payment_method": "bank_transfer", "amount_received": 1.00, "payment_gateway": "mercadopago", "gateway_payment_id": "134140539948", "payment_session_id": 34}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
112	financial_transactions	DELETE	39	{"id": 39, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2026-01-15", "client_id": 3, "paid_date": "2025-11-16T12:00:00", "created_at": "2025-11-16T23:31:13.318503", "net_profit": -1.00, "updated_at": "2025-11-16T23:31:13.318503", "server_cost": 2.00, "unitv_code_id": null, "payment_method": "bank_transfer", "amount_received": 1.00, "payment_gateway": "mercadopago", "gateway_payment_id": "134142089548", "payment_session_id": 35}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
113	financial_transactions	DELETE	40	{"id": 40, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2026-02-15", "client_id": 3, "paid_date": "2025-11-16T12:00:00", "created_at": "2025-11-16T23:45:58.751069", "net_profit": -1.00, "updated_at": "2025-11-16T23:45:58.751069", "server_cost": 2.00, "unitv_code_id": null, "payment_method": "bank_transfer", "amount_received": 1.00, "payment_gateway": "mercadopago", "gateway_payment_id": "134143671032", "payment_session_id": 36}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
114	financial_transactions	DELETE	41	{"id": 41, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2026-03-15", "client_id": 3, "paid_date": "2025-11-17T12:00:00", "created_at": "2025-11-17T15:55:28.936075", "net_profit": -1.00, "updated_at": "2025-11-17T15:55:28.936075", "server_cost": 2.00, "unitv_code_id": null, "payment_method": "bank_transfer", "amount_received": 1.00, "payment_gateway": "mercadopago", "gateway_payment_id": "134217314216", "payment_session_id": 37}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
115	financial_transactions	DELETE	42	{"id": 42, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2026-04-15", "client_id": 3, "paid_date": "2025-11-17T12:00:00", "created_at": "2025-11-17T16:18:25.009106", "net_profit": -1.00, "updated_at": "2025-11-17T16:18:25.009106", "server_cost": 2.00, "unitv_code_id": null, "payment_method": "bank_transfer", "amount_received": 1.00, "payment_gateway": "mercadopago", "gateway_payment_id": "133609187433", "payment_session_id": 38}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
116	financial_transactions	DELETE	43	{"id": 43, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2026-05-15", "client_id": 3, "paid_date": "2025-11-17T12:00:00", "created_at": "2025-11-17T16:28:17.470632", "net_profit": -1.00, "updated_at": "2025-11-17T16:28:17.470632", "server_cost": 2.00, "unitv_code_id": null, "payment_method": "bank_transfer", "amount_received": 1.00, "payment_gateway": "mercadopago", "gateway_payment_id": "133611678595", "payment_session_id": 40}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
117	financial_transactions	DELETE	76	{"id": 76, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2026-06-15", "client_id": 3, "paid_date": "2025-11-17T12:00:00", "created_at": "2025-11-17T16:38:18.773053", "net_profit": -1.00, "updated_at": "2025-11-17T16:38:18.773053", "server_cost": 2.00, "unitv_code_id": null, "payment_method": "bank_transfer", "amount_received": 1.00, "payment_gateway": "mercadopago", "gateway_payment_id": "133613470205", "payment_session_id": 73}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
118	financial_transactions	DELETE	77	{"id": 77, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2026-07-15", "client_id": 3, "paid_date": "2025-11-17T12:00:00", "created_at": "2025-11-17T16:40:29.063051", "net_profit": -1.00, "updated_at": "2025-11-17T16:40:29.063051", "server_cost": 2.00, "unitv_code_id": 4, "payment_method": "bank_transfer", "amount_received": 1.00, "payment_gateway": "mercadopago", "gateway_payment_id": "134220523642", "payment_session_id": 74}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
119	financial_transactions	DELETE	78	{"id": 78, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2026-08-15", "client_id": 3, "paid_date": "2025-11-17T12:00:00", "created_at": "2025-11-17T16:57:38.598119", "net_profit": -1.00, "updated_at": "2025-11-17T16:57:38.598119", "server_cost": 2.00, "unitv_code_id": 5, "payment_method": "bank_transfer", "amount_received": 1.00, "payment_gateway": "mercadopago", "gateway_payment_id": "133613016095", "payment_session_id": 78}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
120	financial_transactions	DELETE	79	{"id": 79, "type": "renewal", "notes": null, "status": "paid", "user_id": 2, "due_date": "2026-09-15", "client_id": 3, "paid_date": "2025-11-17T12:00:00", "created_at": "2025-11-17T17:14:53.234362", "net_profit": -1.00, "updated_at": "2025-11-17T17:14:53.234362", "server_cost": 2.00, "unitv_code_id": 6, "payment_method": "bank_transfer", "amount_received": 1.00, "payment_gateway": "mercadopago", "gateway_payment_id": "134226226824", "payment_session_id": 80}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
121	payment_sessions	DELETE	27	{"id": 27, "amount": 1.00, "status": "paid", "paid_at": "2025-11-05T19:06:41.988122", "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "tayse sena"}, "client_id": 3, "created_at": "2025-11-05T19:05:27.019685", "expires_at": "2025-11-06T19:05:27.018", "payment_token": "9659b149bb30d6b85f43923733a3ee87", "session_token": "1cc24c931f4c5f88f8af77005b6e5ab347d03ce7a178fe7bc2453403ef95cce8", "payment_method": "bank_transfer", "mercadopago_init_point": null, "mercadopago_payment_id": "132045961963", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
122	payment_sessions	DELETE	28	{"id": 28, "amount": 1.00, "status": "paid", "paid_at": "2025-11-05T23:02:32.198401", "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "valton de jesus"}, "client_id": 3, "created_at": "2025-11-05T23:02:06.731061", "expires_at": "2025-11-06T23:02:06.728", "payment_token": "9659b149bb30d6b85f43923733a3ee87", "session_token": "645b8cc55c5dadd1753d132ce826ef1c42c6b766324555316218fb70125ef854", "payment_method": "bank_transfer", "mercadopago_init_point": null, "mercadopago_payment_id": "132677920662", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
123	payment_sessions	DELETE	29	{"id": 29, "amount": 1.00, "status": "paid", "paid_at": "2025-11-05T23:11:33.079384", "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "valton de jesus"}, "client_id": 3, "created_at": "2025-11-05T23:11:03.720147", "expires_at": "2025-11-06T23:11:03.719", "payment_token": "9659b149bb30d6b85f43923733a3ee87", "session_token": "564a8b3d276c8b61497a9a28d715796431a90065d55f6713cd1ccb3e1577c937", "payment_method": "bank_transfer", "mercadopago_init_point": null, "mercadopago_payment_id": "132678836386", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
124	payment_sessions	DELETE	31	{"id": 31, "amount": 1.00, "status": "paid", "paid_at": "2025-11-05T23:19:19.591415", "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "valton de jesus"}, "client_id": 3, "created_at": "2025-11-05T23:19:04.664488", "expires_at": "2025-11-06T23:19:04.662", "payment_token": "9659b149bb30d6b85f43923733a3ee87", "session_token": "1b395b24dd87871b3398149fd755d49a73513fd4e70fc14da624cb2070dd7fba", "payment_method": "bank_transfer", "mercadopago_init_point": null, "mercadopago_payment_id": "132078802959", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
125	payment_sessions	DELETE	32	{"id": 32, "amount": 1.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "Heliton Fernando"}, "client_id": 3, "created_at": "2025-11-13T23:31:21.869696", "expires_at": "2025-11-14T23:31:21.868", "payment_token": "9659b149bb30d6b85f43923733a3ee87", "session_token": "e5434bd6e8ec7df32c964132b361a88a1573107304909025ccf7158a84dfe516", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
126	payment_sessions	DELETE	33	{"id": 33, "amount": 1.00, "status": "paid", "paid_at": "2025-11-15T23:09:24.772143", "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "Heliton Fernando"}, "client_id": 3, "created_at": "2025-11-15T23:08:11.576792", "expires_at": "2025-11-16T23:08:11.574", "payment_token": "9659b149bb30d6b85f43923733a3ee87", "session_token": "ed71c57c78f0f869c89fda426d1864bd36cd98aa4d1aa7cf6cf0e3843bda25c9", "payment_method": "bank_transfer", "mercadopago_init_point": null, "mercadopago_payment_id": "133433233403", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
127	payment_sessions	DELETE	34	{"id": 34, "amount": 1.00, "status": "paid", "paid_at": "2025-11-16T23:17:30.166574", "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "Heliton Fernando"}, "client_id": 3, "created_at": "2025-11-16T23:16:59.183747", "expires_at": "2025-11-17T23:16:59.182", "payment_token": "9659b149bb30d6b85f43923733a3ee87", "session_token": "6616e3582a058e83d1b214703c64de73a66224dbb69f9d5fa8d6578ff1059be4", "payment_method": "bank_transfer", "mercadopago_init_point": null, "mercadopago_payment_id": "134140539948", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
128	payment_sessions	DELETE	24	{"id": 24, "amount": 1.00, "status": "paid", "paid_at": "2025-11-05T18:42:20.577986", "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "tayse sena"}, "client_id": 3, "created_at": "2025-11-05T18:41:53.357234", "expires_at": "2025-11-06T18:41:53.356", "payment_token": "9659b149bb30d6b85f43923733a3ee87", "session_token": "9a1314a802349a2158ea9d4691c3ce95a7c79ac20a3b0a62a0c8b5e612f93ef1", "payment_method": "bank_transfer", "mercadopago_init_point": null, "mercadopago_payment_id": "132643426988", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
129	payment_sessions	DELETE	25	{"id": 25, "amount": 1.00, "status": "paid", "paid_at": "2025-11-05T18:47:48.569957", "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "tayse sena"}, "client_id": 3, "created_at": "2025-11-05T18:47:30.672927", "expires_at": "2025-11-06T18:47:30.671", "payment_token": "9659b149bb30d6b85f43923733a3ee87", "session_token": "c1782e90d703312443980a69e85210a8b2ff67480e6d54e56ec4d40c31559b7c", "payment_method": "bank_transfer", "mercadopago_init_point": null, "mercadopago_payment_id": "132643711432", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
130	payment_sessions	DELETE	26	{"id": 26, "amount": 1.00, "status": "paid", "paid_at": "2025-11-05T19:00:25.751936", "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "tayse sena"}, "client_id": 3, "created_at": "2025-11-05T19:00:07.959353", "expires_at": "2025-11-06T19:00:07.955", "payment_token": "9659b149bb30d6b85f43923733a3ee87", "session_token": "61962dbcc94e40b7314107b31e6276686c692c8281a183a9d7ca9fcb04146d86", "payment_method": "bank_transfer", "mercadopago_init_point": null, "mercadopago_payment_id": "132647338176", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
131	payment_sessions	DELETE	35	{"id": 35, "amount": 1.00, "status": "paid", "paid_at": "2025-11-16T23:31:13.307252", "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "Heliton Fernando"}, "client_id": 3, "created_at": "2025-11-16T23:30:53.617517", "expires_at": "2025-11-17T23:30:53.616", "payment_token": "9659b149bb30d6b85f43923733a3ee87", "session_token": "1fd62d43088adedbed9a965fed600b29600d246905679ce81147667e68cc489e", "payment_method": "bank_transfer", "mercadopago_init_point": null, "mercadopago_payment_id": "134142089548", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
132	payment_sessions	DELETE	36	{"id": 36, "amount": 1.00, "status": "paid", "paid_at": "2025-11-16T23:45:51.908348", "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "Heliton Fernando"}, "client_id": 3, "created_at": "2025-11-16T23:45:37.731117", "expires_at": "2025-11-17T23:45:37.729", "payment_token": "9659b149bb30d6b85f43923733a3ee87", "session_token": "0985c09300638819ce4062bb5c572513792db2d4f18c5d70dd22d8eecd2187f9", "payment_method": "bank_transfer", "mercadopago_init_point": null, "mercadopago_payment_id": "134143671032", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
133	payment_sessions	DELETE	37	{"id": 37, "amount": 1.00, "status": "paid", "paid_at": "2025-11-17T15:55:22.510661", "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "Heliton Fernando"}, "client_id": 3, "created_at": "2025-11-17T15:55:03.164055", "expires_at": "2025-11-18T15:55:03.162", "payment_token": "9659b149bb30d6b85f43923733a3ee87", "session_token": "ee0d050f00b6143b5c4501f0ead5c80ff57228387da41e50acb8914e1c71034e", "payment_method": "bank_transfer", "mercadopago_init_point": null, "mercadopago_payment_id": "134217314216", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
134	payment_sessions	DELETE	38	{"id": 38, "amount": 1.00, "status": "paid", "paid_at": "2025-11-17T16:18:24.983488", "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "Heliton Fernando"}, "client_id": 3, "created_at": "2025-11-17T16:17:55.085028", "expires_at": "2025-11-18T16:17:55.082", "payment_token": "9659b149bb30d6b85f43923733a3ee87", "session_token": "811259a3f7d2cb27b58f424a4a8f2479ec22aecfb556e63347451752d66d7e51", "payment_method": "bank_transfer", "mercadopago_init_point": null, "mercadopago_payment_id": "133609187433", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
135	payment_sessions	DELETE	39	{"id": 39, "amount": 1.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "Heliton Fernando"}, "client_id": 3, "created_at": "2025-11-17T16:19:03.05432", "expires_at": "2025-11-18T16:19:03.053", "payment_token": "9659b149bb30d6b85f43923733a3ee87", "session_token": "928c5e1f9acb3861e83d53bde973d0ace99a572f61700d70c0c314591d9bf9f8", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
136	payment_sessions	DELETE	40	{"id": 40, "amount": 1.00, "status": "paid", "paid_at": "2025-11-17T16:28:17.436146", "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "Heliton Fernando"}, "client_id": 3, "created_at": "2025-11-17T16:26:09.90242", "expires_at": "2025-11-18T16:26:09.901", "payment_token": "9659b149bb30d6b85f43923733a3ee87", "session_token": "6dd67f83768fe26bd513300d01f7212911b8ae83ec667e72cada5879271cff80", "payment_method": "bank_transfer", "mercadopago_init_point": null, "mercadopago_payment_id": "133611678595", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
137	payment_sessions	DELETE	73	{"id": 73, "amount": 1.00, "status": "paid", "paid_at": "2025-11-17T16:38:18.746738", "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "Heliton Fernando"}, "client_id": 3, "created_at": "2025-11-17T16:38:01.014398", "expires_at": "2025-11-18T16:38:01.011", "payment_token": "9659b149bb30d6b85f43923733a3ee87", "session_token": "f8e96dec0c298968d0e44d5a628f0285a1911f50e9f4ff06a75a46c855318bbd", "payment_method": "bank_transfer", "mercadopago_init_point": null, "mercadopago_payment_id": "133613470205", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
138	payment_sessions	DELETE	74	{"id": 74, "amount": 1.00, "status": "paid", "paid_at": "2025-11-17T16:40:29.028635", "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "Heliton Fernando"}, "client_id": 3, "created_at": "2025-11-17T16:38:57.266933", "expires_at": "2025-11-18T16:38:57.266", "payment_token": "9659b149bb30d6b85f43923733a3ee87", "session_token": "d00fba7c0b52856d84442ca6f8f75220dbf181c9423eedc368d58c57b9077028", "payment_method": "bank_transfer", "mercadopago_init_point": null, "mercadopago_payment_id": "134220523642", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
139	payment_sessions	DELETE	75	{"id": 75, "amount": 1.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "Heliton Fernando"}, "client_id": 3, "created_at": "2025-11-17T16:40:57.675528", "expires_at": "2025-11-18T16:40:57.674", "payment_token": "9659b149bb30d6b85f43923733a3ee87", "session_token": "f38cc0a5b032fc3c9cd71ad3ac2d2ad45e3461ac2c21cffc8a2030295256164a", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
140	payment_sessions	DELETE	76	{"id": 76, "amount": 1.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "Heliton Fernando"}, "client_id": 3, "created_at": "2025-11-17T16:51:19.633217", "expires_at": "2025-11-18T16:51:19.632", "payment_token": "9659b149bb30d6b85f43923733a3ee87", "session_token": "fb2378d8ed19169b22177f04a0951063dbe6c7b254295a1d45e3a79cb692d483", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
141	payment_sessions	DELETE	77	{"id": 77, "amount": 1.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "Heliton Fernando"}, "client_id": 3, "created_at": "2025-11-17T16:56:09.718481", "expires_at": "2025-11-18T16:56:09.717", "payment_token": "9659b149bb30d6b85f43923733a3ee87", "session_token": "5c7ba3f1f90c8164028ec5105227fddc23a8f5ebaf41e7e781af284b8404f6d5", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": "134224048606", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
142	payment_sessions	DELETE	78	{"id": 78, "amount": 1.00, "status": "paid", "paid_at": "2025-11-17T16:57:38.579344", "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "Heliton Fernando"}, "client_id": 3, "created_at": "2025-11-17T16:57:14.06844", "expires_at": "2025-11-18T16:57:14.067", "payment_token": "9659b149bb30d6b85f43923733a3ee87", "session_token": "8e6cafb5953682593b074c24c61fe9534b56718df24e01bfac6c4cea568f564e", "payment_method": "bank_transfer", "mercadopago_init_point": null, "mercadopago_payment_id": "133613016095", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
143	payment_sessions	DELETE	79	{"id": 79, "amount": 1.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "Heliton Fernando"}, "client_id": 3, "created_at": "2025-11-17T16:57:56.97814", "expires_at": "2025-11-18T16:57:56.976", "payment_token": "9659b149bb30d6b85f43923733a3ee87", "session_token": "3fe92f669f2bd748ba1852c9f94eadec9fd1b09e3ec8e499ab93a16b5ae94a49", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
144	payment_sessions	DELETE	80	{"id": 80, "amount": 1.00, "status": "paid", "paid_at": "2025-11-17T17:14:53.220682", "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "Heliton Fernando"}, "client_id": 3, "created_at": "2025-11-17T17:14:27.294334", "expires_at": "2025-11-18T17:14:27.29", "payment_token": "9659b149bb30d6b85f43923733a3ee87", "session_token": "32b540ed6bcf79aa88bacf3943a11bf0f927444df1cd9e1651b77f3058f47c69", "payment_method": "bank_transfer", "mercadopago_init_point": null, "mercadopago_payment_id": "134226226824", "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
145	payment_sessions	DELETE	82	{"id": 82, "amount": 1.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "Heliton Fernando"}, "client_id": 3, "created_at": "2025-11-17T18:24:04.824839", "expires_at": "2025-11-18T18:24:04.824", "payment_token": "9659b149bb30d6b85f43923733a3ee87", "session_token": "f9ee65ce8f9c8d7804a2983c3a15e4e32c6d80c6b8dd8cd745812acc05642c49", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
146	payment_sessions	DELETE	83	{"id": 83, "amount": 1.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "Heliton Fernando"}, "client_id": 3, "created_at": "2025-11-17T18:30:56.608162", "expires_at": "2025-11-18T18:30:56.606", "payment_token": "9659b149bb30d6b85f43923733a3ee87", "session_token": "e107b2fbc0108c4ac262ee46438721c85704eae5e902e6a4521b9c590b39ec55", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
147	payment_sessions	DELETE	96	{"id": 96, "amount": 1.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "Heliton Fernando"}, "client_id": 3, "created_at": "2025-11-17T19:06:10.242021", "expires_at": "2025-11-18T19:06:10.241", "payment_token": "9659b149bb30d6b85f43923733a3ee87", "session_token": "06725af4c07be4182daa22c147b800793c0faef31fb51054f841e418a844d584", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
148	payment_sessions	DELETE	101	{"id": 101, "amount": 1.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "Heliton Fernando"}, "client_id": 3, "created_at": "2025-11-17T19:08:43.658263", "expires_at": "2025-11-18T19:08:43.657", "payment_token": "9659b149bb30d6b85f43923733a3ee87", "session_token": "a21af0101e8b082316d5d8925cfb4b7b008d17d3c0908573932ccbbbaf569552", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
149	payment_sessions	DELETE	103	{"id": 103, "amount": 1.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "Heliton Fernando"}, "client_id": 3, "created_at": "2025-11-17T19:09:21.725093", "expires_at": "2025-11-18T19:09:21.724", "payment_token": "9659b149bb30d6b85f43923733a3ee87", "session_token": "b22be96ab55e68f7e9c5fcda09b0640481b1b17bf07f677a1d341289c1028d18", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
150	payment_sessions	DELETE	104	{"id": 104, "amount": 1.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "Heliton Fernando"}, "client_id": 3, "created_at": "2025-11-17T19:10:55.972632", "expires_at": "2025-11-18T19:10:55.97", "payment_token": "9659b149bb30d6b85f43923733a3ee87", "session_token": "2ef6d6f5b99f1f600beae3d22768958db625f96132647ca69ce2f924f2e33330", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
151	payment_sessions	DELETE	111	{"id": 111, "amount": 1.00, "status": "pending", "paid_at": null, "user_id": 2, "currency": "BRL", "metadata": {"pix_amount": 1, "card_amount": 1.1, "client_name": "Heliton Fernando"}, "client_id": 3, "created_at": "2025-11-17T19:59:38.32953", "expires_at": "2025-11-18T19:59:38.328", "payment_token": "9659b149bb30d6b85f43923733a3ee87", "session_token": "6c968072d9d79f7c364ec7900743a4d6893a2859c4fb379f2424b1cbdc19101d", "payment_method": null, "mercadopago_init_point": null, "mercadopago_payment_id": null, "mercadopago_preference_id": null}	\N	gestao_user	2025-11-18 23:53:34.347013	\N	\N	\N
153	clients	DELETE	15	{"id": 15, "name": "oi", "notes": "", "plan_id": 6, "user_id": 2, "due_date": "2025-01-01", "password": "", "username": "", "is_active": true, "server_id": 2, "created_at": "2025-11-19T00:26:34.568282", "device_key": "", "updated_at": "2025-11-19T00:26:34.568282", "mac_address": "", "price_value": 1.00, "payment_token": "8b403b3379322e6fe064a83185248e22", "whatsapp_number": "558593028391"}	\N	gestao_user	2025-11-19 00:26:43.685801	\N	\N	\N
154	whatsapp_instances	UPDATE	23	{"id": 23, "status": "connected", "qr_code": null, "user_id": 2, "provider": "wppconnect", "last_ping": "2025-11-17T23:35:08.838336", "created_at": "2025-11-14T21:04:16.601976", "updated_at": "2025-11-17T23:35:08.838336", "instance_id": null, "connected_at": "2025-11-14T22:19:12.785", "phone_number": null, "instance_name": "user_2", "qr_code_updated_at": "2025-11-14T22:19:05.513809"}	{"id": 23, "status": "connected", "qr_code": null, "user_id": 2, "provider": "wppconnect", "last_ping": "2025-11-19T00:28:19.55487", "created_at": "2025-11-14T21:04:16.601976", "updated_at": "2025-11-19T00:28:19.55487", "instance_id": null, "connected_at": "2025-11-14T22:19:12.785", "phone_number": null, "instance_name": "user_2", "qr_code_updated_at": "2025-11-14T22:19:05.513809"}	gestao_user	2025-11-19 00:28:19.55487	\N	\N	\N
155	whatsapp_instances	UPDATE	23	{"id": 23, "status": "connected", "qr_code": null, "user_id": 2, "provider": "wppconnect", "last_ping": "2025-11-19T00:28:19.55487", "created_at": "2025-11-14T21:04:16.601976", "updated_at": "2025-11-19T00:28:19.55487", "instance_id": null, "connected_at": "2025-11-14T22:19:12.785", "phone_number": null, "instance_name": "user_2", "qr_code_updated_at": "2025-11-14T22:19:05.513809"}	{"id": 23, "status": "connected", "qr_code": null, "user_id": 2, "provider": "wppconnect", "last_ping": "2025-11-19T00:29:33.16666", "created_at": "2025-11-14T21:04:16.601976", "updated_at": "2025-11-19T00:29:33.16666", "instance_id": null, "connected_at": "2025-11-14T22:19:12.785", "phone_number": null, "instance_name": "user_2", "qr_code_updated_at": "2025-11-14T22:19:05.513809"}	gestao_user	2025-11-19 00:29:33.16666	\N	\N	\N
156	payment_settings	UPDATE	1	{"id": 1, "user_id": 2, "created_at": "2025-10-26T18:25:58.331732", "updated_at": "2025-10-26T18:25:58.331732", "payment_domain": "https://pagamentos.comprarecarga.shop", "mercadopago_enabled": true, "mercadopago_public_key": "4a63d4f44e03ce835537c49f7769fca8:3d0af08793f8d1ce78baf67a588001e21f0feb0a467926c036d2eb354fc28e4c745b3c53f6c6126971b6818c4838bd38", "mercadopago_access_token": "51b618e0ff98671c6e88d430c1c1b036:b126c2cff96f2aa9dd6fe1d468ec4568559922a95920dc5ae2be112a06dac2adfd0f3dff091a2f8bc9d60313941f2c017110ce3e1ccf32600733ae4d0b022dc7c9c1d8d986f728ebbca96182a60b4b13", "session_expiration_hours": 24, "send_confirmation_whatsapp": true}	{"id": 1, "user_id": 2, "created_at": "2025-10-26T18:25:58.331732", "updated_at": "2025-11-19T00:31:56.419906", "payment_domain": "https://pagamentos.comprarecarga.shop", "mercadopago_enabled": false, "mercadopago_public_key": "4a63d4f44e03ce835537c49f7769fca8:3d0af08793f8d1ce78baf67a588001e21f0feb0a467926c036d2eb354fc28e4c745b3c53f6c6126971b6818c4838bd38", "mercadopago_access_token": "51b618e0ff98671c6e88d430c1c1b036:b126c2cff96f2aa9dd6fe1d468ec4568559922a95920dc5ae2be112a06dac2adfd0f3dff091a2f8bc9d60313941f2c017110ce3e1ccf32600733ae4d0b022dc7c9c1d8d986f728ebbca96182a60b4b13", "session_expiration_hours": 24, "send_confirmation_whatsapp": true}	gestao_user	2025-11-19 00:31:56.419906	\N	\N	\N
157	payment_settings	UPDATE	1	{"id": 1, "user_id": 2, "created_at": "2025-10-26T18:25:58.331732", "updated_at": "2025-11-19T00:31:56.419906", "payment_domain": "https://pagamentos.comprarecarga.shop", "mercadopago_enabled": false, "mercadopago_public_key": "4a63d4f44e03ce835537c49f7769fca8:3d0af08793f8d1ce78baf67a588001e21f0feb0a467926c036d2eb354fc28e4c745b3c53f6c6126971b6818c4838bd38", "mercadopago_access_token": "51b618e0ff98671c6e88d430c1c1b036:b126c2cff96f2aa9dd6fe1d468ec4568559922a95920dc5ae2be112a06dac2adfd0f3dff091a2f8bc9d60313941f2c017110ce3e1ccf32600733ae4d0b022dc7c9c1d8d986f728ebbca96182a60b4b13", "session_expiration_hours": 24, "send_confirmation_whatsapp": true}	{"id": 1, "user_id": 2, "created_at": "2025-10-26T18:25:58.331732", "updated_at": "2025-11-19T00:31:58.950724", "payment_domain": "https://pagamentos.comprarecarga.shop", "mercadopago_enabled": true, "mercadopago_public_key": "4a63d4f44e03ce835537c49f7769fca8:3d0af08793f8d1ce78baf67a588001e21f0feb0a467926c036d2eb354fc28e4c745b3c53f6c6126971b6818c4838bd38", "mercadopago_access_token": "51b618e0ff98671c6e88d430c1c1b036:b126c2cff96f2aa9dd6fe1d468ec4568559922a95920dc5ae2be112a06dac2adfd0f3dff091a2f8bc9d60313941f2c017110ce3e1ccf32600733ae4d0b022dc7c9c1d8d986f728ebbca96182a60b4b13", "session_expiration_hours": 24, "send_confirmation_whatsapp": true}	gestao_user	2025-11-19 00:31:58.950724	\N	\N	\N
158	payment_settings	DELETE	1	{"id": 1, "user_id": 2, "created_at": "2025-10-26T18:25:58.331732", "updated_at": "2025-11-19T00:31:58.950724", "payment_domain": "https://pagamentos.comprarecarga.shop", "mercadopago_enabled": true, "mercadopago_public_key": "4a63d4f44e03ce835537c49f7769fca8:3d0af08793f8d1ce78baf67a588001e21f0feb0a467926c036d2eb354fc28e4c745b3c53f6c6126971b6818c4838bd38", "mercadopago_access_token": "51b618e0ff98671c6e88d430c1c1b036:b126c2cff96f2aa9dd6fe1d468ec4568559922a95920dc5ae2be112a06dac2adfd0f3dff091a2f8bc9d60313941f2c017110ce3e1ccf32600733ae4d0b022dc7c9c1d8d986f728ebbca96182a60b4b13", "session_expiration_hours": 24, "send_confirmation_whatsapp": true}	\N	gestao_user	2025-11-19 00:32:05.12245	\N	\N	\N
159	payment_settings	INSERT	2	\N	{"id": 2, "user_id": 2, "created_at": "2025-11-19T00:33:55.314431", "updated_at": "2025-11-19T00:33:55.314431", "payment_domain": "https://pagamentos.comprarecarga.shop", "mercadopago_enabled": true, "mercadopago_public_key": "774c9c61379528a8d154de9643887998:c137c6989449ec815991830794b2a329b3bb77c5002a315285b63bf5f2ed61b9c3f1e4ea1c33ebd6921de159c753fd27", "mercadopago_access_token": "3117aad0ca4042224eca024ac6a16a13:6ebb90aefe387cab52ab09c9db148ba47ebf53c8d2715942d7b090ceff846519a3d0c37ea0d43a20aa64bbf4a85131042c7b337476bfd8a4c0a4eda4c012cf6c715dbdfca91ce8045a593a40f2a89fe3", "session_expiration_hours": 24, "send_confirmation_whatsapp": true}	gestao_user	2025-11-19 00:33:55.314431	\N	\N	\N
160	whatsapp_instances	UPDATE	23	{"id": 23, "status": "connected", "qr_code": null, "user_id": 2, "provider": "wppconnect", "last_ping": "2025-11-19T00:29:33.16666", "created_at": "2025-11-14T21:04:16.601976", "updated_at": "2025-11-19T00:29:33.16666", "instance_id": null, "connected_at": "2025-11-14T22:19:12.785", "phone_number": null, "instance_name": "user_2", "qr_code_updated_at": "2025-11-14T22:19:05.513809"}	{"id": 23, "status": "connected", "qr_code": null, "user_id": 2, "provider": "wppconnect", "last_ping": "2025-11-19T00:34:15.06753", "created_at": "2025-11-14T21:04:16.601976", "updated_at": "2025-11-19T00:34:15.06753", "instance_id": null, "connected_at": "2025-11-14T22:19:12.785", "phone_number": null, "instance_name": "user_2", "qr_code_updated_at": "2025-11-14T22:19:05.513809"}	gestao_user	2025-11-19 00:34:15.06753	\N	\N	\N
161	clients	INSERT	16	\N	{"id": 16, "name": "teste", "notes": "", "plan_id": 6, "user_id": 2, "due_date": "2025-01-31", "password": "", "username": "", "is_active": true, "server_id": 2, "created_at": "2025-11-19T01:21:41.290843", "device_key": "", "updated_at": "2025-11-19T01:21:41.290843", "mac_address": "", "price_value": 10.00, "payment_token": "b283bc894e539c95fe20f83059e9c3a0", "whatsapp_number": "558594021963"}	gestao_user	2025-11-19 01:21:41.290843	\N	\N	\N
162	clients	DELETE	16	{"id": 16, "name": "teste", "notes": "", "plan_id": 6, "user_id": 2, "due_date": "2025-01-31", "password": "", "username": "", "is_active": true, "server_id": 2, "created_at": "2025-11-19T01:21:41.290843", "device_key": "", "updated_at": "2025-11-19T01:21:41.290843", "mac_address": "", "price_value": 10.00, "payment_token": "b283bc894e539c95fe20f83059e9c3a0", "whatsapp_number": "558594021963"}	\N	gestao_user	2025-11-19 01:43:49.527919	\N	\N	\N
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: gestao_user
--

COPY public.clients (id, user_id, name, whatsapp_number, plan_id, server_id, price_value, due_date, username, password, mac_address, device_key, notes, is_active, created_at, updated_at, payment_token) FROM stdin;
\.


--
-- Data for Name: financial_transactions; Type: TABLE DATA; Schema: public; Owner: gestao_user
--

COPY public.financial_transactions (id, user_id, client_id, type, amount_received, server_cost, net_profit, due_date, paid_date, status, payment_method, notes, created_at, updated_at, payment_gateway, gateway_payment_id, payment_session_id, unitv_code_id) FROM stdin;
\.


--
-- Data for Name: message_logs; Type: TABLE DATA; Schema: public; Owner: gestao_user
--

COPY public.message_logs (id, user_id, client_id, reminder_id, template_id, message_sent, whatsapp_number, sent_at, status, error_message) FROM stdin;
\.


--
-- Data for Name: message_queue; Type: TABLE DATA; Schema: public; Owner: gestao_user
--

COPY public.message_queue (id, user_id, instance_name, client_id, reminder_id, template_id, whatsapp_number, message, status, priority, scheduled_for, attempts, last_attempt, error_message, created_at, sent_at, send_once) FROM stdin;
\.


--
-- Data for Name: message_templates; Type: TABLE DATA; Schema: public; Owner: gestao_user
--

COPY public.message_templates (id, user_id, name, type, message, is_active, created_at, updated_at) FROM stdin;
1	2	Teste Send Once	pre_vencimento	   Olá {{nome}}, este é um teste de envio único! \n   Você receberá esta mensagem apenas UMA vez.\n{{fatura}}	t	2025-10-29 01:15:41.906356	2025-10-29 01:15:41.906356
\.


--
-- Data for Name: payment_sessions; Type: TABLE DATA; Schema: public; Owner: gestao_user
--

COPY public.payment_sessions (id, client_id, user_id, payment_token, session_token, mercadopago_preference_id, mercadopago_payment_id, mercadopago_init_point, amount, currency, status, payment_method, created_at, expires_at, paid_at, metadata) FROM stdin;
\.


--
-- Data for Name: payment_settings; Type: TABLE DATA; Schema: public; Owner: gestao_user
--

COPY public.payment_settings (id, user_id, mercadopago_enabled, mercadopago_access_token, mercadopago_public_key, payment_domain, session_expiration_hours, send_confirmation_whatsapp, created_at, updated_at) FROM stdin;
2	2	t	3117aad0ca4042224eca024ac6a16a13:6ebb90aefe387cab52ab09c9db148ba47ebf53c8d2715942d7b090ceff846519a3d0c37ea0d43a20aa64bbf4a85131042c7b337476bfd8a4c0a4eda4c012cf6c715dbdfca91ce8045a593a40f2a89fe3	774c9c61379528a8d154de9643887998:c137c6989449ec815991830794b2a329b3bb77c5002a315285b63bf5f2ed61b9c3f1e4ea1c33ebd6921de159c753fd27	https://pagamentos.comprarecarga.shop	24	t	2025-11-19 00:33:55.314431	2025-11-19 00:33:55.314431
\.


--
-- Data for Name: plans; Type: TABLE DATA; Schema: public; Owner: gestao_user
--

COPY public.plans (id, user_id, name, duration_months, num_screens, created_at, is_sigma_plan, sigma_plan_code, sigma_domain, is_live21_plan, is_koffice_plan, koffice_domain, is_uniplay_plan, is_unitv_plan) FROM stdin;
1	2	teste@teste.com	1	1	2025-10-26 18:24:06.907613	f	\N	\N	f	f	\N	f	f
4	2	PACOTE COMPLETO - 1 ANO	12	1	2025-10-28 16:34:31.970241	t	bOxLAQLZ7a	https://starpainel.site	f	f	\N	f	f
5	2	PACOTE IPTV COM ADULTOS 1 MES	1	1	2025-10-28 19:52:09.918602	t	BV4D3rLaqZ	https://dash.turbox.tv.br	f	f	\N	f	f
2	2	cocodel	1	1	2025-10-26 18:30:15.435168	f	\N	\N	t	f	\N	f	f
6	2	P2P AMERICANO 1 MÊS SEM ADULTO	1	1	2025-10-30 12:54:36.470007	t	BKADdn1lrn	https://dash.turbox.tv.br	f	f	\N	f	f
11	2	PACOTE IPTV COM ADULTO 12 MESES	12	1	2025-10-30 13:09:18.347806	t	ANKWPKDPRq	https://dash.turbox.tv.br	f	f	\N	f	f
12	2	teste koffice	1	1	2025-10-31 23:22:05.724026	f	\N	\N	f	t	https://daily3.news	f	f
15	2	plano teste uni	1	1	2025-11-05 17:24:39.116145	f	\N	\N	f	f	\N	t	f
14	2	teste uniplay	1	1	2025-11-05 14:42:53.904252	f	\N	\N	f	f	\N	t	f
16	2	maezinha	1	1	2025-11-07 22:55:57.255885	f	\N	\N	f	f	\N	f	t
17	2	cocodel unitv	1	1	2025-11-15 23:07:35.652015	f	\N	\N	f	f	\N	f	t
20	2	teste unitv 1 mes	1	1	2025-11-17 20:57:32.185555	f	\N	\N	f	f	\N	f	t
21	2	teste unitv 3 mes	3	1	2025-11-17 20:57:48.263759	f	\N	\N	f	f	\N	f	t
\.


--
-- Data for Name: reminder_sent_log; Type: TABLE DATA; Schema: public; Owner: gestao_user
--

COPY public.reminder_sent_log (id, reminder_id, client_id, sent_at) FROM stdin;
\.


--
-- Data for Name: reminders; Type: TABLE DATA; Schema: public; Owner: gestao_user
--

COPY public.reminders (id, user_id, name, template_id, days_offset, send_time, is_active, created_at, updated_at, send_once) FROM stdin;
2	2	TESTE	1	0	22:59:00	t	2025-10-29 01:44:48.243737	2025-10-28 22:58:34.450378	f
1	2	teste Envio Único	1	0	23:29:00	t	2025-10-29 01:38:23.787487	2025-11-13 23:28:29.575491	f
\.


--
-- Data for Name: securevault_users; Type: TABLE DATA; Schema: public; Owner: gestao_user
--

COPY public.securevault_users (id, username, password_hash, totp_secret, totp_enabled, is_admin, last_login, created_at, updated_at) FROM stdin;
1	admin	$2a$10$ozSfJeYefuPx/57j1cvxhO92/VBgmkgHddRUSRbe6tl9xcLtgvMpi	\N	f	t	2025-11-18 23:40:17.730467	2025-11-18 19:02:04.362961	2025-11-18 19:02:04.362961
\.


--
-- Data for Name: servers; Type: TABLE DATA; Schema: public; Owner: gestao_user
--

COPY public.servers (id, user_id, name, cost_per_screen, multiply_by_screens, created_at) FROM stdin;
1	2	teste@teste.com	2.00	t	2025-10-26 18:24:14.170471
2	2	Vi	3.00	t	2025-10-29 23:57:01.713017
\.


--
-- Data for Name: transaction_unitv_codes; Type: TABLE DATA; Schema: public; Owner: gestao_user
--

COPY public.transaction_unitv_codes (id, transaction_id, unitv_code_id, created_at) FROM stdin;
\.


--
-- Data for Name: unitv_codes; Type: TABLE DATA; Schema: public; Owner: gestao_user
--

COPY public.unitv_codes (id, user_id, code, status, delivered_to_client_id, delivered_at, created_at, updated_at) FROM stdin;
8	2	4829176501338492	delivered	\N	2025-11-17 20:59:10.619891	2025-11-17 20:52:43.022119	2025-11-18 23:35:07.193825
9	2	9056712845031127	delivered	\N	2025-11-17 21:12:43.01703	2025-11-17 20:52:43.033649	2025-11-18 23:35:07.193825
10	2	3176089427516640	delivered	\N	2025-11-17 21:13:53.896934	2025-11-17 20:52:43.036899	2025-11-18 23:35:07.193825
11	2	7285491063328715	delivered	\N	2025-11-17 21:13:53.901182	2025-11-17 20:52:43.040048	2025-11-18 23:35:07.193825
12	2	6601847390254468	delivered	\N	2025-11-17 21:13:53.902971	2025-11-17 20:52:43.043548	2025-11-18 23:35:07.193825
13	2	1948732056881043	delivered	\N	2025-11-17 23:13:46.475944	2025-11-17 20:52:43.047277	2025-11-18 23:35:07.193825
14	2	8530127694405871	delivered	\N	2025-11-17 23:20:02.077756	2025-11-17 20:52:43.049654	2025-11-18 23:35:07.193825
15	2	2395061877149036	delivered	\N	2025-11-17 23:20:52.190251	2025-11-17 20:52:43.053286	2025-11-18 23:35:07.193825
16	2	5078914632204589	delivered	\N	2025-11-17 23:20:52.194688	2025-11-17 20:52:43.055399	2025-11-18 23:35:07.193825
17	2	7812403965187204	delivered	\N	2025-11-17 23:20:52.19652	2025-11-17 20:52:43.057273	2025-11-18 23:35:07.193825
7	2	8540284059672920	delivered	\N	2025-11-17 18:38:58.28524	2025-11-17 18:38:12.071023	2025-11-18 23:35:12.824484
4	2	1234123412341234	delivered	\N	2025-11-17 16:40:29.05184	2025-11-17 16:39:46.933221	2025-11-18 23:53:34.347013
5	2	1230123012301230	delivered	\N	2025-11-17 16:57:38.591618	2025-11-17 16:51:01.278702	2025-11-18 23:53:34.347013
6	2	4321432143214321	delivered	\N	2025-11-17 17:14:53.229729	2025-11-17 16:51:01.287532	2025-11-18 23:53:34.347013
\.


--
-- Data for Name: user_subscription_payments; Type: TABLE DATA; Schema: public; Owner: gestao_user
--

COPY public.user_subscription_payments (id, user_id, mercadopago_payment_id, amount, days_added, status, payment_method, created_at, paid_at, previous_subscription_end, new_subscription_end, metadata) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: gestao_user
--

COPY public.users (id, name, email, password_hash, phone, role, subscription_start, subscription_end, is_active, max_clients, max_instances, messages_per_minute, created_at, updated_at) FROM stdin;
1	Administrador	admin@sistema.com	$2b$10$gQVuK2hC5JTZL7Wjd.ON5.8c9UqarNzEu16ysDg19JI5NDomeMbyy	\N	admin	\N	\N	t	100	1	10	2025-10-26 18:18:23.079093	2025-10-26 18:18:23.079093
2	teste@teste.com	teste@teste.com	$2b$10$oMRQmpbtMjS6qBkz3AHpzuPOpxi09pGiQ8gDJpuhX9OZRvMzg/sIS		user	2025-10-26	2025-11-26	t	100	1	5	2025-10-26 18:23:47.186251	2025-10-26 18:23:47.186251
3	teste2@teste.com	teste2@teste.com	$2b$10$quKpagorEu5twkrchc9sv.jrXoaTu9zwwuT/dBxacKrIuyErjmTUi		user	2025-11-14	2025-12-14	t	100	1	5	2025-11-14 23:12:58.115227	2025-11-14 23:12:58.115227
\.


--
-- Data for Name: whatsapp_instances; Type: TABLE DATA; Schema: public; Owner: gestao_user
--

COPY public.whatsapp_instances (id, user_id, instance_name, instance_id, phone_number, status, qr_code, qr_code_updated_at, connected_at, last_ping, created_at, updated_at, provider) FROM stdin;
60	3	user_3	\N	\N	connected	\N	2025-11-14 23:29:54.544321	2025-11-14 23:30:29.264	2025-11-14 23:49:46.985153	2025-11-14 23:29:40.859218	2025-11-14 23:49:46.985153	whatsappwebjs
23	2	user_2	\N	\N	connected	\N	2025-11-14 22:19:05.513809	2025-11-14 22:19:12.785	2025-11-19 00:34:15.06753	2025-11-14 21:04:16.601976	2025-11-19 00:34:15.06753	wppconnect
\.


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gestao_user
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 162, true);


--
-- Name: clients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gestao_user
--

SELECT pg_catalog.setval('public.clients_id_seq', 16, true);


--
-- Name: financial_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gestao_user
--

SELECT pg_catalog.setval('public.financial_transactions_id_seq', 92, true);


--
-- Name: message_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gestao_user
--

SELECT pg_catalog.setval('public.message_logs_id_seq', 3, true);


--
-- Name: message_queue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gestao_user
--

SELECT pg_catalog.setval('public.message_queue_id_seq', 3, true);


--
-- Name: message_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gestao_user
--

SELECT pg_catalog.setval('public.message_templates_id_seq', 1, true);


--
-- Name: payment_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gestao_user
--

SELECT pg_catalog.setval('public.payment_sessions_id_seq', 139, true);


--
-- Name: payment_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gestao_user
--

SELECT pg_catalog.setval('public.payment_settings_id_seq', 2, true);


--
-- Name: plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gestao_user
--

SELECT pg_catalog.setval('public.plans_id_seq', 21, true);


--
-- Name: reminder_sent_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gestao_user
--

SELECT pg_catalog.setval('public.reminder_sent_log_id_seq', 1, true);


--
-- Name: reminders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gestao_user
--

SELECT pg_catalog.setval('public.reminders_id_seq', 2, true);


--
-- Name: securevault_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gestao_user
--

SELECT pg_catalog.setval('public.securevault_users_id_seq', 3, true);


--
-- Name: servers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gestao_user
--

SELECT pg_catalog.setval('public.servers_id_seq', 2, true);


--
-- Name: transaction_unitv_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gestao_user
--

SELECT pg_catalog.setval('public.transaction_unitv_codes_id_seq', 8, true);


--
-- Name: unitv_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gestao_user
--

SELECT pg_catalog.setval('public.unitv_codes_id_seq', 17, true);


--
-- Name: user_subscription_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gestao_user
--

SELECT pg_catalog.setval('public.user_subscription_payments_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gestao_user
--

SELECT pg_catalog.setval('public.users_id_seq', 35, true);


--
-- Name: whatsapp_instances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gestao_user
--

SELECT pg_catalog.setval('public.whatsapp_instances_id_seq', 61, true);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: clients clients_payment_token_key; Type: CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_payment_token_key UNIQUE (payment_token);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: financial_transactions financial_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.financial_transactions
    ADD CONSTRAINT financial_transactions_pkey PRIMARY KEY (id);


--
-- Name: message_logs message_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.message_logs
    ADD CONSTRAINT message_logs_pkey PRIMARY KEY (id);


--
-- Name: message_queue message_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.message_queue
    ADD CONSTRAINT message_queue_pkey PRIMARY KEY (id);


--
-- Name: message_templates message_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.message_templates
    ADD CONSTRAINT message_templates_pkey PRIMARY KEY (id);


--
-- Name: message_templates message_templates_user_id_name_key; Type: CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.message_templates
    ADD CONSTRAINT message_templates_user_id_name_key UNIQUE (user_id, name);


--
-- Name: payment_sessions payment_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.payment_sessions
    ADD CONSTRAINT payment_sessions_pkey PRIMARY KEY (id);


--
-- Name: payment_sessions payment_sessions_session_token_key; Type: CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.payment_sessions
    ADD CONSTRAINT payment_sessions_session_token_key UNIQUE (session_token);


--
-- Name: payment_settings payment_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.payment_settings
    ADD CONSTRAINT payment_settings_pkey PRIMARY KEY (id);


--
-- Name: payment_settings payment_settings_user_id_key; Type: CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.payment_settings
    ADD CONSTRAINT payment_settings_user_id_key UNIQUE (user_id);


--
-- Name: plans plans_pkey; Type: CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_pkey PRIMARY KEY (id);


--
-- Name: plans plans_user_id_name_key; Type: CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_user_id_name_key UNIQUE (user_id, name);


--
-- Name: reminder_sent_log reminder_sent_log_pkey; Type: CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.reminder_sent_log
    ADD CONSTRAINT reminder_sent_log_pkey PRIMARY KEY (id);


--
-- Name: reminder_sent_log reminder_sent_log_reminder_id_client_id_key; Type: CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.reminder_sent_log
    ADD CONSTRAINT reminder_sent_log_reminder_id_client_id_key UNIQUE (reminder_id, client_id);


--
-- Name: reminders reminders_pkey; Type: CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.reminders
    ADD CONSTRAINT reminders_pkey PRIMARY KEY (id);


--
-- Name: securevault_users securevault_users_pkey; Type: CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.securevault_users
    ADD CONSTRAINT securevault_users_pkey PRIMARY KEY (id);


--
-- Name: securevault_users securevault_users_username_key; Type: CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.securevault_users
    ADD CONSTRAINT securevault_users_username_key UNIQUE (username);


--
-- Name: servers servers_pkey; Type: CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.servers
    ADD CONSTRAINT servers_pkey PRIMARY KEY (id);


--
-- Name: servers servers_user_id_name_key; Type: CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.servers
    ADD CONSTRAINT servers_user_id_name_key UNIQUE (user_id, name);


--
-- Name: transaction_unitv_codes transaction_unitv_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.transaction_unitv_codes
    ADD CONSTRAINT transaction_unitv_codes_pkey PRIMARY KEY (id);


--
-- Name: transaction_unitv_codes transaction_unitv_codes_transaction_id_unitv_code_id_key; Type: CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.transaction_unitv_codes
    ADD CONSTRAINT transaction_unitv_codes_transaction_id_unitv_code_id_key UNIQUE (transaction_id, unitv_code_id);


--
-- Name: unitv_codes unique_user_code; Type: CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.unitv_codes
    ADD CONSTRAINT unique_user_code UNIQUE (user_id, code);


--
-- Name: unitv_codes unitv_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.unitv_codes
    ADD CONSTRAINT unitv_codes_pkey PRIMARY KEY (id);


--
-- Name: user_subscription_payments user_subscription_payments_mercadopago_payment_id_key; Type: CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.user_subscription_payments
    ADD CONSTRAINT user_subscription_payments_mercadopago_payment_id_key UNIQUE (mercadopago_payment_id);


--
-- Name: user_subscription_payments user_subscription_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.user_subscription_payments
    ADD CONSTRAINT user_subscription_payments_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: whatsapp_instances whatsapp_instances_instance_name_key; Type: CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.whatsapp_instances
    ADD CONSTRAINT whatsapp_instances_instance_name_key UNIQUE (instance_name);


--
-- Name: whatsapp_instances whatsapp_instances_pkey; Type: CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.whatsapp_instances
    ADD CONSTRAINT whatsapp_instances_pkey PRIMARY KEY (id);


--
-- Name: whatsapp_instances whatsapp_instances_user_id_key; Type: CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.whatsapp_instances
    ADD CONSTRAINT whatsapp_instances_user_id_key UNIQUE (user_id);


--
-- Name: idx_audit_changed_at; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_audit_changed_at ON public.audit_log USING btree (changed_at DESC);


--
-- Name: idx_audit_changed_by; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_audit_changed_by ON public.audit_log USING btree (changed_by);


--
-- Name: idx_audit_operation; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_audit_operation ON public.audit_log USING btree (operation);


--
-- Name: idx_audit_table_name; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_audit_table_name ON public.audit_log USING btree (table_name);


--
-- Name: idx_clients_due_date; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_clients_due_date ON public.clients USING btree (due_date);


--
-- Name: idx_clients_payment_token; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_clients_payment_token ON public.clients USING btree (payment_token);


--
-- Name: idx_clients_user_id; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_clients_user_id ON public.clients USING btree (user_id);


--
-- Name: idx_financial_transactions_unitv_code; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_financial_transactions_unitv_code ON public.financial_transactions USING btree (unitv_code_id);


--
-- Name: idx_message_logs_client_id; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_message_logs_client_id ON public.message_logs USING btree (client_id);


--
-- Name: idx_message_logs_sent_at; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_message_logs_sent_at ON public.message_logs USING btree (sent_at);


--
-- Name: idx_payment_sessions_client_id; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_payment_sessions_client_id ON public.payment_sessions USING btree (client_id);


--
-- Name: idx_payment_sessions_mercadopago_payment_id; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_payment_sessions_mercadopago_payment_id ON public.payment_sessions USING btree (mercadopago_payment_id);


--
-- Name: idx_payment_sessions_payment_token; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_payment_sessions_payment_token ON public.payment_sessions USING btree (payment_token);


--
-- Name: idx_payment_sessions_session_token; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_payment_sessions_session_token ON public.payment_sessions USING btree (session_token);


--
-- Name: idx_payment_sessions_status; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_payment_sessions_status ON public.payment_sessions USING btree (status);


--
-- Name: idx_plans_is_koffice; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_plans_is_koffice ON public.plans USING btree (is_koffice_plan);


--
-- Name: idx_plans_is_live21; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_plans_is_live21 ON public.plans USING btree (is_live21_plan);


--
-- Name: idx_plans_is_sigma; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_plans_is_sigma ON public.plans USING btree (is_sigma_plan);


--
-- Name: idx_plans_is_uniplay; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_plans_is_uniplay ON public.plans USING btree (is_uniplay_plan);


--
-- Name: idx_plans_is_unitv; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_plans_is_unitv ON public.plans USING btree (is_unitv_plan);


--
-- Name: idx_plans_user_id; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_plans_user_id ON public.plans USING btree (user_id);


--
-- Name: idx_queue_status_scheduled; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_queue_status_scheduled ON public.message_queue USING btree (status, scheduled_for);


--
-- Name: idx_queue_user_status; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_queue_user_status ON public.message_queue USING btree (user_id, status);


--
-- Name: idx_reminder_sent_log_client; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_reminder_sent_log_client ON public.reminder_sent_log USING btree (client_id);


--
-- Name: idx_reminder_sent_log_reminder; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_reminder_sent_log_reminder ON public.reminder_sent_log USING btree (reminder_id);


--
-- Name: idx_reminders_user_id; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_reminders_user_id ON public.reminders USING btree (user_id);


--
-- Name: idx_securevault_users_username; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_securevault_users_username ON public.securevault_users USING btree (username);


--
-- Name: idx_servers_user_id; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_servers_user_id ON public.servers USING btree (user_id);


--
-- Name: idx_templates_user_id; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_templates_user_id ON public.message_templates USING btree (user_id);


--
-- Name: idx_transaction_codes_code; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_transaction_codes_code ON public.transaction_unitv_codes USING btree (unitv_code_id);


--
-- Name: idx_transaction_codes_transaction; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_transaction_codes_transaction ON public.transaction_unitv_codes USING btree (transaction_id);


--
-- Name: idx_transactions_client_id; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_transactions_client_id ON public.financial_transactions USING btree (client_id);


--
-- Name: idx_transactions_gateway_payment_id; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_transactions_gateway_payment_id ON public.financial_transactions USING btree (gateway_payment_id);


--
-- Name: idx_transactions_paid_date; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_transactions_paid_date ON public.financial_transactions USING btree (paid_date);


--
-- Name: idx_transactions_status; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_transactions_status ON public.financial_transactions USING btree (status);


--
-- Name: idx_transactions_unitv_code_id; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_transactions_unitv_code_id ON public.financial_transactions USING btree (unitv_code_id);


--
-- Name: idx_transactions_user_id; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_transactions_user_id ON public.financial_transactions USING btree (user_id);


--
-- Name: idx_unitv_codes_available; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_unitv_codes_available ON public.unitv_codes USING btree (user_id) WHERE ((status)::text = 'available'::text);


--
-- Name: idx_unitv_codes_status; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_unitv_codes_status ON public.unitv_codes USING btree (user_id, status);


--
-- Name: idx_unitv_codes_user_id; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_unitv_codes_user_id ON public.unitv_codes USING btree (user_id);


--
-- Name: idx_user_subscription_payments_mp_id; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_user_subscription_payments_mp_id ON public.user_subscription_payments USING btree (mercadopago_payment_id);


--
-- Name: idx_user_subscription_payments_status; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_user_subscription_payments_status ON public.user_subscription_payments USING btree (status);


--
-- Name: idx_user_subscription_payments_user_id; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_user_subscription_payments_user_id ON public.user_subscription_payments USING btree (user_id);


--
-- Name: idx_whatsapp_instances_provider; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_whatsapp_instances_provider ON public.whatsapp_instances USING btree (provider);


--
-- Name: idx_whatsapp_instances_status; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_whatsapp_instances_status ON public.whatsapp_instances USING btree (status);


--
-- Name: idx_whatsapp_instances_user_id; Type: INDEX; Schema: public; Owner: gestao_user
--

CREATE INDEX idx_whatsapp_instances_user_id ON public.whatsapp_instances USING btree (user_id);


--
-- Name: clients audit_clients; Type: TRIGGER; Schema: public; Owner: gestao_user
--

CREATE TRIGGER audit_clients AFTER INSERT OR DELETE OR UPDATE ON public.clients FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();


--
-- Name: financial_transactions audit_financial_transactions; Type: TRIGGER; Schema: public; Owner: gestao_user
--

CREATE TRIGGER audit_financial_transactions AFTER INSERT OR DELETE OR UPDATE ON public.financial_transactions FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();


--
-- Name: payment_sessions audit_payment_sessions; Type: TRIGGER; Schema: public; Owner: gestao_user
--

CREATE TRIGGER audit_payment_sessions AFTER INSERT OR DELETE OR UPDATE ON public.payment_sessions FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();


--
-- Name: payment_settings audit_payment_settings; Type: TRIGGER; Schema: public; Owner: gestao_user
--

CREATE TRIGGER audit_payment_settings AFTER INSERT OR DELETE OR UPDATE ON public.payment_settings FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();


--
-- Name: plans audit_plans; Type: TRIGGER; Schema: public; Owner: gestao_user
--

CREATE TRIGGER audit_plans AFTER INSERT OR DELETE OR UPDATE ON public.plans FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();


--
-- Name: servers audit_servers; Type: TRIGGER; Schema: public; Owner: gestao_user
--

CREATE TRIGGER audit_servers AFTER INSERT OR DELETE OR UPDATE ON public.servers FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();


--
-- Name: users audit_users; Type: TRIGGER; Schema: public; Owner: gestao_user
--

CREATE TRIGGER audit_users AFTER INSERT OR DELETE OR UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();


--
-- Name: whatsapp_instances audit_whatsapp_instances; Type: TRIGGER; Schema: public; Owner: gestao_user
--

CREATE TRIGGER audit_whatsapp_instances AFTER INSERT OR DELETE OR UPDATE ON public.whatsapp_instances FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();


--
-- Name: clients trigger_set_payment_token; Type: TRIGGER; Schema: public; Owner: gestao_user
--

CREATE TRIGGER trigger_set_payment_token BEFORE INSERT ON public.clients FOR EACH ROW EXECUTE FUNCTION public.set_payment_token();


--
-- Name: unitv_codes trigger_update_unitv_codes_updated_at; Type: TRIGGER; Schema: public; Owner: gestao_user
--

CREATE TRIGGER trigger_update_unitv_codes_updated_at BEFORE UPDATE ON public.unitv_codes FOR EACH ROW EXECUTE FUNCTION public.update_unitv_codes_updated_at();


--
-- Name: clients clients_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id) ON DELETE RESTRICT;


--
-- Name: clients clients_server_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_server_id_fkey FOREIGN KEY (server_id) REFERENCES public.servers(id) ON DELETE RESTRICT;


--
-- Name: clients clients_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: financial_transactions financial_transactions_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.financial_transactions
    ADD CONSTRAINT financial_transactions_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: financial_transactions financial_transactions_unitv_code_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.financial_transactions
    ADD CONSTRAINT financial_transactions_unitv_code_id_fkey FOREIGN KEY (unitv_code_id) REFERENCES public.unitv_codes(id) ON DELETE SET NULL;


--
-- Name: financial_transactions financial_transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.financial_transactions
    ADD CONSTRAINT financial_transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: financial_transactions fk_payment_session; Type: FK CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.financial_transactions
    ADD CONSTRAINT fk_payment_session FOREIGN KEY (payment_session_id) REFERENCES public.payment_sessions(id);


--
-- Name: financial_transactions fk_unitv_code; Type: FK CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.financial_transactions
    ADD CONSTRAINT fk_unitv_code FOREIGN KEY (unitv_code_id) REFERENCES public.unitv_codes(id) ON DELETE SET NULL;


--
-- Name: message_logs message_logs_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.message_logs
    ADD CONSTRAINT message_logs_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: message_logs message_logs_reminder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.message_logs
    ADD CONSTRAINT message_logs_reminder_id_fkey FOREIGN KEY (reminder_id) REFERENCES public.reminders(id) ON DELETE SET NULL;


--
-- Name: message_logs message_logs_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.message_logs
    ADD CONSTRAINT message_logs_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.message_templates(id) ON DELETE SET NULL;


--
-- Name: message_logs message_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.message_logs
    ADD CONSTRAINT message_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: message_queue message_queue_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.message_queue
    ADD CONSTRAINT message_queue_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: message_queue message_queue_reminder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.message_queue
    ADD CONSTRAINT message_queue_reminder_id_fkey FOREIGN KEY (reminder_id) REFERENCES public.reminders(id) ON DELETE CASCADE;


--
-- Name: message_queue message_queue_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.message_queue
    ADD CONSTRAINT message_queue_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.message_templates(id) ON DELETE CASCADE;


--
-- Name: message_queue message_queue_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.message_queue
    ADD CONSTRAINT message_queue_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: message_templates message_templates_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.message_templates
    ADD CONSTRAINT message_templates_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: payment_sessions payment_sessions_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.payment_sessions
    ADD CONSTRAINT payment_sessions_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: payment_sessions payment_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.payment_sessions
    ADD CONSTRAINT payment_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: payment_settings payment_settings_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.payment_settings
    ADD CONSTRAINT payment_settings_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: plans plans_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: reminder_sent_log reminder_sent_log_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.reminder_sent_log
    ADD CONSTRAINT reminder_sent_log_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: reminder_sent_log reminder_sent_log_reminder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.reminder_sent_log
    ADD CONSTRAINT reminder_sent_log_reminder_id_fkey FOREIGN KEY (reminder_id) REFERENCES public.reminders(id) ON DELETE CASCADE;


--
-- Name: reminders reminders_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.reminders
    ADD CONSTRAINT reminders_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.message_templates(id) ON DELETE CASCADE;


--
-- Name: reminders reminders_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.reminders
    ADD CONSTRAINT reminders_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: servers servers_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.servers
    ADD CONSTRAINT servers_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: transaction_unitv_codes transaction_unitv_codes_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.transaction_unitv_codes
    ADD CONSTRAINT transaction_unitv_codes_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.financial_transactions(id) ON DELETE CASCADE;


--
-- Name: transaction_unitv_codes transaction_unitv_codes_unitv_code_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.transaction_unitv_codes
    ADD CONSTRAINT transaction_unitv_codes_unitv_code_id_fkey FOREIGN KEY (unitv_code_id) REFERENCES public.unitv_codes(id) ON DELETE CASCADE;


--
-- Name: unitv_codes unitv_codes_delivered_to_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.unitv_codes
    ADD CONSTRAINT unitv_codes_delivered_to_client_id_fkey FOREIGN KEY (delivered_to_client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- Name: unitv_codes unitv_codes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.unitv_codes
    ADD CONSTRAINT unitv_codes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_subscription_payments user_subscription_payments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.user_subscription_payments
    ADD CONSTRAINT user_subscription_payments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: whatsapp_instances whatsapp_instances_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gestao_user
--

ALTER TABLE ONLY public.whatsapp_instances
    ADD CONSTRAINT whatsapp_instances_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict WUYxPsVeCtZDao8NMiWvOxM4oXqkaqXdbCt0eEIpGQNB8gMOe1MdtmKMxMifdQX

